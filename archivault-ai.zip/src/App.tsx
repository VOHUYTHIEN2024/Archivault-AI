/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useRef, useEffect } from 'react';
import ReactMarkdown from 'react-markdown';
import { GoogleGenAI } from "@google/genai";
import { 
  Camera, 
  Upload, 
  RefreshCcw, 
  Copy, 
  Check, 
  Sparkles, 
  Building2, 
  Layers, 
  Maximize2,
  Trash2,
  Loader2,
  Info,
  Plus,
  Zap,
  Settings2,
  PenTool,
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import Markdown from 'react-markdown';
import { CATEGORIES, PRESET_DATA, CAMERA_ANGLES } from './constants';

// Initialize Gemini
const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

const INTERIOR_PROMPT_TEMPLATES: Record<string, string> = {
  toancanh: "interior design, wide-angle panoramic shot capturing the entire room's volume, showing the spatial relationship between flooring, ceiling design, and primary furniture layout, volumetric lighting, photorealistic 8k",
  trungcanh: "interior design, medium shot focusing on the main functional zone (e.g., seating area or bed), highlighting furniture proportions, wall decor, and ambient lighting fixtures, architectural photography",
  cancanh: "interior design, detailed close-up showing material textures, fabric weaving on furniture, wood grain finishes, and small decorative table accessories, shallow depth of field, sharp focus",
  sieucan: "interior design, extreme macro shot focusing on interior material junctions, showing intricate stitching on leather, micro-textures of marble veining or brushed metal hardware, ultra-detailed"
};

const TREND_PROMPT_DATA: Record<string, { title: string; content: string }[]> = {
  toancanh: [
      { title: "1.1 BỐ CỤC TOÀN CẢNH 4 GÓC (CAO, THẤP, TRÁI QUA BỤI, PHẢI QUA CÀNH)", 
        content: "tạo 1 ảnh mới gồm {N} ảnh ghép lại : ảnh toàn cảnh các góc nhìn trên cao nhìn xuống , dưới thấp nhìn lên , bên trái nhìn qua bụi cây nhìn vào công trình , bên phải nhìn qua 1 nhánh cây nhỏ nhìn vào công trình từ xa . Độ phân giải 8k, duy trì sự nhất quán hình ảnh tuyệt đối với ảnh gốc." },
      { title: "1.2 TOÀN CẢNH 4 GÓC - THỜI TIẾT TRỜI MƯA ĐƯỜNG ƯỚT", 
        content: "tạo 1 ảnh mới gồm {N} ảnh ghép lại : ảnh toàn cảnh các góc nhìn trên cao nhìn xuống , dưới thấp nhìn lên , bên trái nhìn qua bụi cây nhìn vào công trình , bên phải nhìn qua 1 nhánh cây nhỏ nhìn vào công trình từ xa . chuyển ảnh gốc sang thời tiết trời mưa , đường ướt . Độ phân giải 8k, duy trì sự nhất quán hình ảnh tuyệt đối với ảnh gốc." },
      { title: "1.3 TOÀN CẢNH 4 GÓC - 4 THỜI TIẾT NGẪU NHIÊN (ĐÊM, NẮNG, MƯA, MÂY)", 
        content: "tạo 1 ảnh mới gồm {N} ảnh ghép lại : ảnh toàn cảnh các góc nhìn trên cao nhìn xuống , dưới thấp nhìn lên , bên trái nhìn qua bụi cây nhìn vào công trình , bên phải nhìn qua 1 nhánh cây nhỏ nhìn vào công trình từ xa . chuyển ảnh gốc sang thời tiết trời mưa , trời nắng gắt có tia nắng , trời ban đêm bầu trời xanh có đèn hắt cây , và trời ít mây nhẹ nhàng xuất hiện 4 thời tiết khác nhau ngẫu nhiên ở 4 hình . Độ phân giải 8k, duy trì sự nhất quán hình ảnh tuyệt đối với ảnh gốc." },
      { title: "1.4 TOÀN CẢNH 4 GÓC - NẮNG NGHỆ THUẬT TIA NẮNG", 
        content: "tạo 1 ảnh mới gồm {N} ảnh ghép lại : ảnh toàn cảnh các góc nhìn trên cao nhìn xuống , dưới thấp nhìn lên , bên trái nhìn qua bụi cây nhìn vào công trình , bên phải nhìn qua 1 nhánh cây nhỏ nhìn vào công trình từ xa . chuyển ảnh gốc sang thời tiết nắng có tia nắng nghệ thuật . Độ phân giải 8k, duy trì sự nhất quán hình ảnh tuyệt đối với ảnh gốc." }
  ],
  trungcanh: [
      { title: "2.1 TRUNG CẢNH - CÁC GÓC ĐẸP NGẪU NHIÊN", 
        content: "tạo 1 ảnh mới gồm {N} ảnh ghép lại : ảnh trung cảnh chụp ngẫu nhiên từ các góc đẹp của công trình . Độ phân giải 8k, duy trì sự nhất quán hình ảnh tuyệt đối với ảnh gốc." },
      { title: "2.2 TRUNG CẢNH - TRỜI MƯA ĐƯỜNG ƯỚT", 
        content: "tạo 1 ảnh mới gồm {N} ảnh ghép lại : ảnh trung cảnh chụp ngẫu nhiên từ các góc đẹp của công trình . chuyển ảnh gốc sang thời tiết trời mưa đường ướt . Độ phân giải 8k, duy trì sự nhất quán hình ảnh tuyệt đối với ảnh gốc." },
      { title: "2.3 TRUNG CẢNH - 2 ẢNH TỐI & 2 ẢNH NẮNG GẮT TIA NẮNG", 
        content: "tạo 1 ảnh mới gồm {N} ảnh ghép lại : ảnh trung cảnh chụp ngẫu nhiên từ các góc đẹp của công trình . chuyển ảnh gốc sang 2 ảnh thời tiết trời tối bầu trời mùa xanh và có đèn hắt cây và đèn trong công trình và có 2 ảnh thời tiết nắng gắt có tia nắng chiếu vào công trình đầy nghệ thuật . Độ phân giải 8k, duy trì sự nhất quán hình ảnh tuyệt đối với ảnh gốc." }
  ],
  cancanh: [
      { title: "3.1 CẬN CẢNH - CHI TIẾT VẬT LIỆU", 
        content: "tạo 1 ảnh mới gồm {N} ảnh ghép lại : ảnh cận cảnh chi tiết chụp ngẫu nhiên từ các góc đẹp của công trình . thể hiện rõ chi tiết vật liệu . Độ phân giải 8k, duy trì sự nhất quán hình ảnh tuyệt đối với ảnh gốc." },
      { title: "3.2 CẬN CẢNH - TRỜI MƯA, GIỌT NƯỚC BỀ MẶT", 
        content: "tạo 1 ảnh mới gồm {N} ảnh ghép lại : ảnh cận cảnh chi tiết chụp ngẫu nhiên từ các góc đẹp của công trình . thể hiện rõ chi tiết vật liệu . chuyển sang thời tiết trời mưa , chi tiết nước và giọt nước trên bề mặt vật liệu hoặc lá cây . Độ phân giải 8k, duy trì sự nhất quán hình ảnh tuyệt đối với ảnh gốc." },
      { title: "3.3 CẬN CẢNH - TIA NẮNG NGHỆ THUẬT", 
        content: "tạo 1 ảnh mới gồm {N} ảnh ghép lại : ảnh cận cảnh chi tiết chụp ngẫu nhiên từ các góc đẹp của công trình . thể hiện rõ chi tiết vật liệu . chuyển sang thời tiết có tia nắng vào công trình . Độ phân giải 8k, duy trì sự nhất quán hình ảnh tuyệt đối với ảnh gốc." }
  ],
  sieucan: [
      { title: "4.1 SIÊU CẬN CẢNH - SIÊU CHI TIẾT VẬT LIỆU", 
        content: "tạo 1 ảnh mới gồm {N} ảnh ghép lại : ảnh siêu cận cảnh siêu chi tiết chụp ngẫu nhiên từ các góc đẹp của công trình . thể hiện rõ chi tiết vật liệu . Độ phân giải 8k, duy trì sự nhất quán hình ảnh tuyệt đối với ảnh gốc." },
      { title: "4.2 SIÊU CẬN CẢNH - TRỜI MƯA, GIỌT NƯỚC NGHỆ THUẬT", 
        content: "tạo 1 ảnh mới gồm {N} ảnh ghép lại : ảnh siêu cận cảnh siêu chi tiết chụp ngẫu nhiên từ các góc đẹp của công trình . thể hiện rõ chi tiết vật liệu . chuyển thời tiết sang trời mưa . các góc rất nghệ thuật . thấy rõ các chi tiết giọt nước trên bề mặt vật liệu hoặc trên tán cây nếu có . Độ phân giải 8k, duy trì sự nhất quán hình ảnh tuyệt đối với ảnh gốc." }
  ]
};

const ARCHITECTURAL_STYLES = [
  { id: 'indochine', name: 'Indochine', description: 'Indochine architecture style, tropical fusion, dark wood accents, colonial era influence, warm lighting.', image: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=400&q=80' },
  { id: 'mediterranean', name: 'Địa Trung Hải', description: 'Mediterranean architecture, rustic terracotta tones, bright white stucco walls, archways, coastal vibe.', image: 'https://images.unsplash.com/photo-1512917774080-9991f1c4c750?auto=format&fit=crop&w=400&q=80' },
  { id: 'tropical', name: 'TROPICAL', description: 'Tropical modern architecture, lush exotic landscaping, wood and bamboo materials, open-air pavilion, palm trees, warm sunlight, natural stone, seamless indoor-outdoor integration.', image: 'https://images.unsplash.com/photo-1540541338287-41700207dee6?auto=format&fit=crop&w=400&q=80' },
  { id: 'modern', name: 'Modern', description: 'Glass, steel, and clean geometric lines.', image: 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&q=80&w=400' },
  { id: 'neoclassical', name: 'Neoclassical', description: 'Elegant columns and luxurious proportions.', image: 'https://images.unsplash.com/photo-1518780664697-55e3ad937233?auto=format&fit=crop&q=80&w=400' },
  { id: 'minimalist', name: 'Minimalist', description: 'Simple shapes and organic textures.', image: 'https://images.unsplash.com/photo-1449156001933-469bcf99d72e?auto=format&fit=crop&q=80&w=400' },
];

const EXTERIOR_PROMPT_GROUPS = [
  {
    name: "GROUP 1: NHÓM STYLE NGHỆ THUẬT (ARTISTIC – CONCEPT)",
    cards: [
      { title: "1. Sketch (Phác thảo tay)", content: "Architectural hand-drawn sketch, loose pencil lines, graphite, rough hatching, concept phase, white paper background." },
      { title: "2. Watercolor (Màu nước)", content: "Architectural watercolor painting, soft washes, bleeding edges, vibrant colors, artistic illustration, loose brush strokes." },
      { title: "3. Ink + Wash (Bút kim + màu nước)", content: "Architectural ink and wash illustration, crisp black fineliner outlines, subtle watercolor splashes, technical yet artistic." },
      { title: "4. Collage (Cắt dán kiến trúc)", content: "Architectural post-digital collage, flat textures, cutout people, abstract composition, muted pastel color palette, minimalist graphic style." },
      { title: "5. Concept Illustration", content: "Stylized architectural concept illustration, atmospheric lighting, ethereal mood, clean gradients, narrative architecture." },
    ]
  },
  {
    name: "GROUP 2: NHÓM STYLE DIỄN HỌA KHÁI NIỆM (CONCEPTUAL / NPR)",
    cards: [
      { title: "6. Diagram / Sơ đồ kiến trúc", content: "Architectural exploded axonometric diagram, technical drawing, clear annotations, dashed lines, clean white background, blueprint style." },
      { title: "7. Line Art / White Model", content: "Minimalist architectural line art, pure white physical scale model, ambient occlusion, soft studio lighting, clay render, structural focus, no textures." },
      { title: "8. Minimal Render (Soft render)", content: "Soft architectural render, minimalist aesthetic, diffuse natural lighting, pastel tones, smooth surfaces, tranquil atmosphere, photorealistic but soft." },
    ]
  },
  {
    name: "GROUP 3: NHÓM PHONG CÁCH ĐẶC BIỆT",
    cards: [
      { title: "9. AI Concept Style", content: "Futuristic parametric architecture concept, biomorphic forms, hyper-detailed, cinematic lighting, unreal engine 5 render." },
      { title: "10. Isometric / Axonometric", content: "Architectural isometric view, 3D orthographic projection, cutaway section, detailed interior and exterior, miniature diorama aesthetic." },
      { title: "11. Vintage / Retro Architecture", content: "Retro 1970s modernist architecture, mid-century modern aesthetic, vintage film photography, kodachrome colors, nostalgic atmosphere, grainy texture." },
      { title: "12. Tropical Modern Visualization", content: "Tropical modernism architecture, lush exotic jungle context, wood and concrete materials, expansive glass, warm golden hour lighting, photorealistic." },
    ]
  }
];

const INTERIOR_PROMPT_GROUPS = [
  {
    name: "GROUP 1: NHÓM STYLE NGHỆ THUẬT (ARTISTIC – CONCEPT)",
    cards: [
      { title: "1. Sketch Interior", content: "Interior architectural sketch, loose pencil lines, graphite, rough hatching, concept phase, white paper background, interior visualization." },
      { title: "2. Watercolor Interior", content: "Interior watercolor painting, soft washes, bleeding edges, vibrant colors, artistic illustration, loose brush strokes." },
      { title: "3. Ink + Wash", content: "Interior ink and wash illustration, crisp black fineliner outlines, subtle watercolor splashes, technical yet artistic, interior sketching." },
      { title: "4. Collage Interior", content: "Interior post-digital collage, flat textures, abstract composition, muted pastel color palette, minimalist graphic style." },
      { title: "5. Concept Illustration", content: "Stylized interior concept illustration, atmospheric lighting, ethereal mood, clean gradients, narrative interior design." },
    ]
  },
  {
    name: "GROUP 2: NHÓM STYLE DIỄN HỌA KHÁI NIỆM (NPR – NON PHOTOREAL)",
    cards: [
      { title: "6. White Model / Clay Render", content: "Minimalist interior line art, pure white physical scale model, ambient occlusion, soft studio lighting, clay render, spatial focus, no textures." },
      { title: "7. Minimal Render (Soft render)", content: "Soft interior render, minimalist aesthetic, diffuse ambient lighting, pastel tones, smooth surfaces, photorealistic but soft." },
      { title: "8. Diagram Interior", content: "Interior exploded axonometric diagram, technical drawing, clear annotations, dashed lines, clean white background, blueprint style." },
    ]
  },
  {
    name: "GROUP 3: NHÓM STYLE TREND MẠNH (AI + XU HƯỚNG MỚI)",
    cards: [
      { title: "9. Warm Minimalism", content: "Warm minimalist interior design, organic textures, soft warm lighting, beige and neutral tones, wabi-sabi influence, inviting atmosphere, photorealistic." },
      { title: "10. Color Drenching / Hue Drenching", content: "Color drenching interior design, monochromatic bold color palette painted across walls ceiling and trim, dramatic lighting, contemporary styling." },
      { title: "11. Material Focus / Texture Rendering", content: "Interior visualization with extreme material focus, high-resolution macro textures, wood grain, stone veins, tactile fabrics, realistic PBR materials, path tracing." },
      { title: "12. Biophilic Interior", content: "Biophilic interior design, abundant indoor plants, living green walls, natural materials, seamless indoor-outdoor connection, sunlight filtering through leaves." },
      { title: "13. Vintage / Retro Interior", content: "Retro 1970s interior design, mid-century modern furniture, vintage film photography aesthetic, kodachrome colors, nostalgic atmosphere." },
      { title: "14. Maximalist / Pattern-heavy", content: "Maximalist interior design, pattern-heavy wallpaper, eclectic furniture mix, rich bold colors, layered textures, curated clutter, highly detailed." },
    ]
  }
];

function getClosestMidjourneyAR(width: number, height: number) {
  const ratio = width / height;
  const midjourneyRatios = [
    { ar: "--ar 16:9", value: 16 / 9 },
    { ar: "--ar 3:2",  value: 3 / 2 },
    { ar: "--ar 4:3",  value: 4 / 3 },
    { ar: "--ar 5:4",  value: 5 / 4 },
    { ar: "--ar 1:1",  value: 1 },
    { ar: "--ar 4:5",  value: 4 / 5 },
    { ar: "--ar 3:4",  value: 3 / 4 },
    { ar: "--ar 2:3",  value: 2 / 3 },
    { ar: "--ar 9:16", value: 9 / 16 }
  ];

  let closestMatch = midjourneyRatios[0];
  let minDifference = Math.abs(ratio - midjourneyRatios[0].value);

  for (let i = 1; i < midjourneyRatios.length; i++) {
    let currentDifference = Math.abs(ratio - midjourneyRatios[i].value);
    if (currentDifference < minDifference) {
      minDifference = currentDifference;
      closestMatch = midjourneyRatios[i];
    }
  }

  return closestMatch.ar;
}

export default function App() {
  const [image, setImage] = useState<string | null>(null);
  const [file, setFile] = useState<File | null>(null);
  const [trendImage, setTrendImage] = useState<string | null>(null);
  const [trendFile, setTrendFile] = useState<File | null>(null);
  const [trendLayout, setTrendLayout] = useState('4');
  const [trendView, setTrendView] = useState('toancanh');
  const [trendMode, setTrendMode] = useState<'exterior' | 'interior'>('exterior');
  const [trendResults, setTrendResults] = useState<{ title: string; content: string }[]>([]);
  const [history, setHistory] = useState<{ 
    title: string; 
    content: any; 
    id: number; 
    timestamp: string; 
    type: 'A' | 'B' | 'C' | 'D';
    metadata?: any;
    targetCardId?: string;
  }[]>([]);
  const [selectedHistoryId, setSelectedHistoryId] = useState<number | null>(null);
  const [highlightedCardId, setHighlightedCardId] = useState<string | null>(null);
  const [videoScriptResult, setVideoScriptResult] = useState<string | null>(null);
  const [isVideoScriptLoading, setIsVideoScriptLoading] = useState(false);
  
  // Inpainting State
  const [editImage, setEditImage] = useState<string | null>(null);
  const [editFile, setEditFile] = useState<File | null>(null);
  const [editRefImage, setEditRefImage] = useState<string | null>(null);
  const [editRefFile, setEditRefFile] = useState<File | null>(null);
  const [editTool, setEditTool] = useState<'brush' | 'lasso'>('brush');
  const [brushSize, setBrushSize] = useState(20);
  const [editInstruction, setEditInstruction] = useState("");
  const [expImage, setExpImage] = useState<string | null>(null);
  const [expFile, setExpFile] = useState<File | null>(null);
  const [expAspectRatio, setExpAspectRatio] = useState<string>("--ar 16:9");
  const [isEditGenerating, setIsEditGenerating] = useState(false);
  const [isDrawing, setIsDrawing] = useState(false);

  const [style, setStyle] = useState(ARCHITECTURAL_STYLES[0]);
  const [activeTab, setActiveTab] = useState<'preset' | 'custom'>('preset');
  const [activeMainTab, setActiveMainTab] = useState<'A' | 'B' | 'C' | 'D'>('A');
  const [activeExpTab, setActiveExpTab] = useState<'ngoaitat' | 'noithat' | 'videoscript' | null>(null);
  const [expAccordion, setExpAccordion] = useState<number>(1);
  const [videoMode, setVideoMode] = useState<'tong' | 'chitiet'>('tong');
  const [videoFrames, setVideoFrames] = useState<string[]>([]);
  const [videoDuration, setVideoDuration] = useState('10');
  const [videoShots, setVideoShots] = useState(5);
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [activeCategory, setActiveCategory] = useState('gocpho');
  const [selectedPreset, setSelectedPreset] = useState("");
  const [selectedAngle, setSelectedAngle] = useState("p3");
  const [extraDesc, setExtraDesc] = useState("");
  const [activeAccordion, setActiveAccordion] = useState<number>(1); // Default open step 1
  const [analysisMode, setAnalysisMode] = useState<'PHÂN TÍCH VẬT LIỆU' | 'AI TỰ ĐỀ XUẤT'>('PHÂN TÍCH VẬT LIỆU');
  const [isGenerating, setIsGenerating] = useState(false);
  const [prompt, setPrompt] = useState<string | null>(null);
  const [gallery, setGallery] = useState<{ url: string; file: File }[]>([]);
  const [isEditing, setIsEditing] = useState(false);
  const [tempPrompt, setTempPrompt] = useState<string>("");
  const [copied, setCopied] = useState(false);
  const [viCopied, setViCopied] = useState(false);
  const [styleRef, setStyleRef] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  
  const fileInputRef = useRef<HTMLInputElement>(null);
  const trendFileInputRef = useRef<HTMLInputElement>(null);
  const editFileInputRef = useRef<HTMLInputElement>(null);
  const editRefFileInputRef = useRef<HTMLInputElement>(null);
  const expFileInputRef = useRef<HTMLInputElement>(null);
  const galleryInputRef = useRef<HTMLInputElement>(null);
  const styleRefInputRef = useRef<HTMLInputElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const imageRef = useRef<HTMLImageElement>(null);

  const startDrawing = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.lineWidth = brushSize;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.strokeStyle = 'rgba(204, 168, 82, 0.5)';
    setIsDrawing(true);
  };

  const draw = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isDrawing) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.lineTo(x, y);
    ctx.stroke();
  };

  const stopDrawing = () => {
    setIsDrawing(false);
  };

  const clearMask = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
  };

  const handleImageLoad = () => {
    const img = imageRef.current;
    const canvas = canvasRef.current;
    if (img && canvas) {
      // BƯỚC 3: Căn chỉnh lại Canvas (Canvas Re-calibration)
      canvas.width = img.clientWidth;
      canvas.height = img.clientHeight;

      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.lineCap = 'round';
        ctx.lineJoin = 'round';
        ctx.strokeStyle = 'rgba(204, 168, 82, 0.5)';
        ctx.lineWidth = brushSize;
      }
    }
  };

  const resetApp = () => {
    if (confirm("Bạn có chắc chắn muốn làm mới toàn bộ cài đặt không?")) {
      setImage(null);
      setFile(null);
      setTrendImage(null);
      setTrendFile(null);
      setTrendResults([]);
      setTrendLayout('4');
      setTrendView('toancanh');
      setEditImage(null);
      setEditFile(null);
      setEditRefImage(null);
      setEditRefFile(null);
      setEditInstruction("");
      setStyle(ARCHITECTURAL_STYLES[0]);
      setActiveMainTab('A');
      setIsSidebarCollapsed(false);
      setActiveCategory('gocpho');
      setSelectedPreset("");
      setSelectedAngle("p3");
      setExtraDesc("");
      setActiveAccordion(1);
      setAnalysisMode('PHÂN TÍCH VẬT LIỆU');
      setPrompt(null);
      setGallery([]);
      setIsEditing(false);
      setStyleRef(null);
      setError(null);
    }
  };

  const addToHistory = (title: string, content: any, type: 'A' | 'C' | 'B' | 'D', metadata?: any, targetCardId?: string) => {
    const newEntry = {
      id: Date.now(),
      title,
      content,
      type,
      metadata,
      targetCardId,
      timestamp: new Date().toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' })
    };
    setHistory(prev => [newEntry, ...prev].slice(0, 10));
    setSelectedHistoryId(newEntry.id);
  };

  const loadFromHistory = (item: any) => {
    setSelectedHistoryId(item.id);
    if (item.type === 'D' && item.targetCardId) {
      // Reverse Highlight Step
      setActiveMainTab('D');
      
      // Determine sub-tab
      if (item.targetCardId.startsWith('style-card-ext')) {
        setActiveExpTab('ngoaitat');
      } else {
        setActiveExpTab('noithat');
      }

      setHighlightedCardId(item.targetCardId);
      
      // Delay scroll to allow DOM update
      setTimeout(() => {
        const targetElement = document.getElementById(item.targetCardId);
        if (targetElement) {
          targetElement.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }
      }, 300);

      setTimeout(() => setHighlightedCardId(null), 3000);
    } else if (item.type === 'C') {
      setActiveMainTab('C');
      setTrendResults(item.content);
      setPrompt(null);
    } else {
      setActiveMainTab(item.type);
      setPrompt(item.content);
      
      // Step 3 (Optional): Restore Sidebar State
      if (item.metadata) {
        if (item.type === 'B') {
          if (item.metadata.instruction !== undefined) setEditInstruction(item.metadata.instruction);
          if (item.metadata.tool !== undefined) setEditTool(item.metadata.tool);
          if (item.metadata.size !== undefined) setBrushSize(item.metadata.size);
        } else if (item.type === 'A') {
          if (item.metadata.styleId) {
            const s = ARCHITECTURAL_STYLES.find(st => st.id === item.metadata.styleId);
            if (s) setStyle(s);
          }
          if (item.metadata.preset !== undefined) setSelectedPreset(item.metadata.preset);
          if (item.metadata.angle !== undefined) setSelectedAngle(item.metadata.angle);
          if (item.metadata.extra !== undefined) setExtraDesc(item.metadata.extra);
          
          // Open relevant accordions if needed, or just let it be
        } else if (item.type === 'C') {
          if (item.metadata.view) setTrendView(item.metadata.view);
          if (item.metadata.layout) setTrendLayout(item.metadata.layout);
        }
      }
    }
  };

  const toggleAccordion = (step: number) => {
    setActiveAccordion(prev => prev === step ? 0 : step);
  };

  const toggleEdit = () => {
    if (isEditing) {
      setPrompt(tempPrompt);
      setIsEditing(false);
    } else {
      setTempPrompt(prompt || "");
      setIsEditing(true);
    }
  };

  const handleGalleryUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFiles = Array.from(e.target.files || []);
    if (selectedFiles.length > 0) {
      const remainingSlots = 5 - gallery.length;
      const filesToAdd = selectedFiles.slice(0, remainingSlots);
      
      filesToAdd.forEach(file => {
        const reader = new FileReader();
        reader.onloadend = () => {
          setGallery(prev => [...prev.slice(0, 4), { url: reader.result as string, file }].slice(0, 5));
        };
        reader.readAsDataURL(file);
      });
    }
  };

  const removeGalleryImage = (index: number) => {
    setGallery(prev => prev.filter((_, i) => i !== index));
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (selectedFile) {
      setFile(selectedFile);
      const reader = new FileReader();
      reader.onloadend = () => {
        setImage(reader.result as string);
        setActiveAccordion(2); // Jump to step 2 after upload
      };
      reader.readAsDataURL(selectedFile);
    }
  };

  const [copiedId, setCopiedId] = useState<number | null>(null);

  const copyCardToClipboard = (text: string, id: number) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };
  const handleTrendImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (selectedFile) {
      setTrendFile(selectedFile);
      const reader = new FileReader();
      reader.onloadend = () => {
        setTrendImage(reader.result as string);
      };
      reader.readAsDataURL(selectedFile);
    }
  };

  const handleEditImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (selectedFile) {
      // BƯỚC 1: Lưu Lịch Sử & Làm sạch (Pre-upload Cleanup)
      if (activeMainTab === 'B' && prompt) {
        const isAlreadyInHistory = history.some(h => h.content === prompt);
        if (!isAlreadyInHistory) {
          addToHistory(`Edit Request Backup`, prompt, 'B', { instruction: editInstruction, tool: editTool, size: brushSize });
        }
      }

      setPrompt(null);
      setEditInstruction("");
      clearMask();

      // BƯỚC 2: Nạp ảnh & Phóng to (Image Transfer)
      setEditFile(selectedFile);
      const reader = new FileReader();
      reader.onloadend = () => {
        setEditImage(reader.result as string);
      };
      reader.readAsDataURL(selectedFile);
    }
  };

  const handleEditRefImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (selectedFile) {
      setEditRefFile(selectedFile);
      const reader = new FileReader();
      reader.onloadend = () => {
        setEditRefImage(reader.result as string);
      };
      reader.readAsDataURL(selectedFile);
    }
  };

  const handleExpImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (selectedFile) {
      setExpFile(selectedFile);
      const reader = new FileReader();
      reader.onloadend = () => {
        const result = reader.result as string;
        setExpImage(result);
        
        // TẠO ẢNH ẢO ĐỂ LẤY KÍCH THƯỚC (WIDTH/HEIGHT)
        const imgObj = new Image();
        imgObj.onload = () => {
          const ar = getClosestMidjourneyAR(imgObj.width, imgObj.height);
          setExpAspectRatio(ar);
          console.log(`[Hệ thống] Cỡ ảnh: ${imgObj.width}x${imgObj.height}px -> Tỷ lệ tự động: ${ar}`);
        };
        imgObj.src = result;
      };
      reader.readAsDataURL(selectedFile);
    }
  };

  const handleStyleRefUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (selectedFile) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setStyleRef(reader.result as string);
      };
      reader.readAsDataURL(selectedFile);
    }
  };

  const copyToClipboard = () => {
    if (prompt) {
      navigator.clipboard.writeText(prompt);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const copyViToClipboard = () => {
    if (prompt) {
      // Logic from user request adapted to the markdown structure we use
      const startMarker = "### BẢN PROMPT TIẾNG VIỆT";
      const endMarker = "### ENGLISH PROMPT";
      
      let textToCopy = "";
      const startIndex = prompt.indexOf(startMarker);
      const endIndex = prompt.indexOf(endMarker);

      if (startIndex !== -1 && endIndex !== -1) {
        textToCopy = prompt.substring(startIndex, endIndex).trim();
      } else if (startIndex !== -1) {
        textToCopy = prompt.substring(startIndex).trim();
      } else {
        textToCopy = prompt;
      }

      navigator.clipboard.writeText(textToCopy);
      setViCopied(true);
      setTimeout(() => setViCopied(false), 2000);
    }
  };

  const handleGenerateEdit = async () => {
    if (!editImage) {
      alert("Vui lòng tải lên một Ảnh Hiện Trạng trước!");
      return;
    }
    if (!editInstruction.trim()) {
      alert("Vui lòng nhập yêu cầu chỉnh sửa!");
      return;
    }

    setIsEditGenerating(true);
    setPrompt(null);
    setError(null);

    try {
      // Simulate API call for Inpainting prompt generation
      setTimeout(() => {
        let dynamicInstruction = editInstruction.trim();
        
        // Bổ sung điều kiện (IF) cho Ảnh Tham Chiếu
        if (editRefImage) {
          dynamicInstruction += " Apply the referenced material texture at STRICT REAL WORLD SCALE and accurate physical proportions so the output does not look fake or CGI.";
        }

        const finalPrompt = `VAI TRÒ HỆ THỐNG: Chuyên gia thiết kế nội thất & Kỹ sư Prompt AI xuất sắc.
NHIỆM VỤ: Tạo ra một bản render ảnh thực (photorealistic) cao cấp dựa trên ảnh hiện trạng, tập trung chỉnh sửa vùng khoanh chọn.
GIAO THỨC ĐA GÓC NHÌN: 
- Hình ảnh 1 là ĐIỂM NEO CHÍNH (PRIMARY ANCHOR).
- DUY TRÌ tính nhất quán cấu trúc tuyệt đối của công trình.

PHẦN 0: [KHÓA HÌNH KHỐI & CẤU TRÚC]
Phân tích và khóa chặt phối cảnh, hình khối kiến trúc hiện hữu. Đảm bảo ánh sáng và đổ bóng của đối tượng mới phải khớp hoàn toàn với môi trường xung quanh trong ảnh gốc.

PHẦN 1: [CHI TIẾT CHỈNH SỬA - EDIT REQUEST]
NỘI DUNG YÊU CẦU: "${dynamicInstruction}"
[MODE: INPAINTING]
- Chọn vùng bằng: ${editTool === 'brush' ? 'Cọ vẽ (Brush)' : 'Lasso'}
- Kích thước chi tiết: ${brushSize}px

PHẦN 2: [CHẤT LƯỢNG KỸ THUẬT]
Shot on Fujifilm GFX 100S, architectural photography, 8K, RAW, realistic shadows, high-fidelity materials, volumetric lighting, photorealistic textures.

---
### DÀN THÔNG SỐ KỸ THUẬT (TECHNICAL PARAMETERS)
1. CAMERA & OPTICS: Fujifilm GFX 100S, 35mm Prime Lens, f/11.
2. MATERIALS: Real textures matching environment.
3. NEGATIVE: No CGI, No painting, No artifacts.
`;
        setPrompt(finalPrompt);
        addToHistory(`Edit Request`, finalPrompt, 'B', { instruction: editInstruction, tool: editTool, size: brushSize });
        setIsEditGenerating(false);
      }, 1500);
    } catch (err) {
      setError("Có lỗi xảy ra khi tạo prompt chỉnh sửa.");
      setIsEditGenerating(false);
    }
  };

  const handleGenerateTrend = async () => {
    if (!trendImage) {
      alert("Vui lòng tải lên một Ảnh Tham Chiếu trước!");
      return;
    }

    setIsGenerating(true);
    setTrendResults([]);
    setError(null);

    try {
      if (trendMode === 'exterior') {
        // Simulate analysis delay
        setTimeout(() => {
          const rawPrompts = TREND_PROMPT_DATA[trendView] || [];
          const processedPrompts = rawPrompts.map(p => {
            let finalContent = p.content.replace(/{N}/g, trendLayout);
            if (trendLayout === "1") {
              finalContent = finalContent.replace("gồm 1 ảnh ghép lại :", "với bối cảnh:");
            }
            return { ...p, content: finalContent };
          });

          setTrendResults(processedPrompts);
          
          const layoutText = ['1 Ảnh', '2 Ảnh', '4 Ảnh', '6 Ảnh'][['1','2','4','6'].indexOf(trendLayout)] || trendLayout;
          addToHistory(`Trend Exterior (${layoutText})`, processedPrompts, 'C', { view: trendView, layout: trendLayout });
          setIsGenerating(false);
        }, 1200);
      } else {
        // Interior generation logic
        setTimeout(() => {
          const numImages = parseInt(trendLayout);
          const basePrompt = INTERIOR_PROMPT_TEMPLATES[trendView];
          
          const results = [];
          for (let i = 1; i <= numImages; i++) {
            const finalContent = `A professional [1x${numImages}] grid collage. Panel ${i}: ${basePrompt}. Maintain consistent interior lighting, realistic shadows, and high-fidelity textures matching the reference image.`;
            results.push({
              title: `PHƯƠNG ÁN NỘI THẤT ${i}`,
              content: finalContent
            });
          }

          setTrendResults(results);
          addToHistory(`Trend Interior (${numImages} Ảnh)`, results, 'C', { view: trendView, layout: trendLayout });
          setIsGenerating(false);
        }, 1000);
      }

    } catch (err) {
      setError("Có lỗi xảy ra khi tạo prompt. Vui lòng thử lại.");
      setIsGenerating(false);
    }
  };

  const handleGenerateVideoScript = () => {
    if (videoMode !== 'tong') {
      alert("Chế độ TỔNG NHANH hiện đang là chế độ duy nhất hỗ trợ xuất kịch bản tự động.");
      return;
    }

    if (videoFrames.length === 0) {
      alert("Vui lòng tải lên ít nhất 1 ảnh trong phần 'ẢNH (TỐI ĐA 10)' để làm tham chiếu.");
      return;
    }

    const totalSeconds = parseInt(videoDuration);
    const totalShots = videoShots;

    if (!totalSeconds || totalSeconds <= 0) {
      alert("Thời gian (giây) phải lớn hơn 0.");
      return;
    }

    if (!totalShots || totalShots <= 0) {
      alert("Số lượng phân cảnh (shots) phải lớn hơn 0.");
      return;
    }

    // Switch to video script tab to show progress
    setActiveExpTab('videoscript');
    setIsVideoScriptLoading(true);
    setVideoScriptResult(null);

    // Simulate AI analysis delay
    setTimeout(() => {
      const blockDuration = (totalSeconds / totalShots).toFixed(1);

      let markdown = `VN: "Chào bạn, với tư cách là một đạo diễn hình ảnh chuyên nghiệp, tôi đã thiết kế kịch bản điện ảnh cho công trình kiến trúc hiện đại này. Video sẽ dẫn người xem từ trên không đến những chi tiết vật liệu tinh xảo và kết thúc bằng vẻ lung linh của ngôi nhà khi lên đèn."\n\n`;
      markdown += `EN: "Hello, as a professional cinematographer, I have designed a cinematic script for this modern architectural masterpiece. The video will guide viewers from an aerial perspective down to the exquisite material details, concluding with the luminous glow of the house as it lights up at dusk."\n\n`;
      markdown += `---\n**BẢN KỊCH BẢN VIDEO CHI TIẾT | DETAILED VIDEO SCRIPT**\n\n`;
      markdown += `- **Tổng thời gian | Total Time:** ${totalSeconds} giây / seconds\n`;
      markdown += `- **Tổng số block | Total Blocks:** ${totalShots} block(s)\n`;
      markdown += `- **Cốt truyện | Storyline:** \n`;
      markdown += `  - *VN:* Một hành trình điện ảnh khám phá sự chuyển mình của không gian từ quy mô tổng thể đến từng thớ thịt của vật liệu, khép lại bằng sự giao thoa huyền ảo giữa ánh sáng nhân tạo và màn đêm.\n`;
      markdown += `  - *EN:* A cinematic journey exploring the transformation of space from a master plan perspective to the very texture of materials, ending with a magical interplay between artificial light and the night sky.\n\n---\n`;

      const technicalKeywords = "8K resolution, hyper-realistic, cinematic lighting, shot on 35mm lens, unreal engine 5.4 render, ultra-stable camera, volumetric lighting, ray-traced reflections";

      for (let i = 1; i <= totalShots; i++) {
        const frameIdx = (i - 1) % videoFrames.length;
        
        // Narrative progression logic
        let phaseEN = "";
        let phaseVN = "";
        let lightingEN = "natural daylight, soft shadows";
        let lightingVN = "ánh sáng ban ngày tự nhiên, đổ bóng mềm";
        let angleEN = "";
        let angleVN = "";

        if (i <= Math.ceil(totalShots * 0.3)) {
          // Initial: Aerial/Drone
          angleEN = "Aerial Drone/Establishing Shot";
          angleVN = "Góc quay trên không (Drone) / Cảnh thiết lập";
          phaseEN = "Establishing the architectural massing and its surrounding environment";
          phaseVN = "Thiết lập hình khối kiến trúc và môi trường xung quanh";
        } else if (i <= Math.ceil(totalShots * 0.7)) {
          // Middle: Macro/Material
          angleEN = "Macro/Close-Up Detail Shot";
          angleVN = "Cận cảnh / Chi tiết vật liệu (Macro)";
          phaseEN = "Focusing on material textures: wood, stone, glass and craftsmanship";
          phaseVN = "Tập trung vào thớ thịt của vật liệu: gỗ, đá, kính và sự tinh xảo";
        } else {
          // Final: Twilight/Glow
          angleEN = "Medium Tracking Shot at Twilight";
          angleVN = "Trung cảnh bám theo vào lúc chập choạng tối";
          phaseEN = "Showcasing the building's luminous glow and artificial lighting highlights";
          phaseVN = "Thể hiện vẻ lung linh của công trình và các điểm nhấn ánh sáng nhân tạo";
          lightingEN = "golden hour transitioning to twilight, warm interior glow, volumetric luminescence";
          lightingVN = "giờ vàng chuyển sang hoàng hôn, ánh sáng nội thất ấm áp, độ rực rỡ thể tích";
        }

        const sfxVN = i === 1 ? 'Tiếng gió nhẹ lướt qua' : i % 2 === 0 ? 'Âm thanh tự nhiên vang xa' : 'Tiếng bước chân trên sàn đá';
        const sfxEN = i === 1 ? 'Subtle wind whistling' : i % 2 === 0 ? 'Ambient nature sounds' : 'Footsteps on stone flooring';

        markdown += `**BLOCK ${blockDuration}s THỨ ${i} | BLOCK ${i}**\n`;
        markdown += `- **Ảnh tham chiếu | Reference Image:** Ảnh số ${frameIdx + 1}\n`;
        markdown += `- **Góc máy | Camera Angle:** ${angleEN} / ${angleVN}\n`;
        markdown += `- **Câu lệnh Video & Âm thanh | Video & Audio Prompt (For Veo 3.1 / Sora):** \n`;
        markdown += `  - 🇬🇧 **[EN]:** Cinematic ${angleEN} of the structure based on image ${frameIdx + 1}. ${phaseEN}. ${lightingEN}. ${technicalKeywords}. Ultra-stable, shake-free camera movement. **Audio:** ${sfxEN}.\n`;
        markdown += `  - 🇻🇳 **[VN]:** Cảnh quay điện ảnh ${angleVN} dựa trên ảnh ${frameIdx + 1}. ${phaseVN}. ${lightingVN}. Chất lượng 8K siêu thực, ánh sáng điện ảnh, camera chống rung tuyệt đối. **Âm thanh:** ${sfxVN}.\n\n`;
      }

      markdown += `---\n[Kết thúc danh sách | End of script]`;
      
      setVideoScriptResult(markdown);
      setIsVideoScriptLoading(false);
      
      // Store in history
      addToHistory(`Kịch bản Video (${totalSeconds}s)`, markdown, 'B');
    }, 2000);
  };

  const handleGenerate = async () => {
    if (!image || !file) return;

    setIsGenerating(true);
    setPrompt(null);
    setError(null);

    const currentPreset = PRESET_DATA[activeCategory]?.find(p => p.value === selectedPreset);
    const currentAngle = CAMERA_ANGLES.find(a => a.value === selectedAngle);

    const systemPrompt = `
[Đóng vai: Bạn là một Chuyên gia Thiết kế Nội thất, Kiến trúc sư trưởng và Kỹ sư Prompt AI xuất sắc.
Nhiệm vụ: Phân tích ảnh hiện trạng (nội thất/ngoại thất) và viết kịch bản mô tả (prompt) thiết kế chuyên sâu.

BẮT BUỘC xuất kết quả theo cấu trúc sau:

VAI TRÒ HỆ THỐNG: Nhiếp ảnh gia kiến trúc chuyên nghiệp & Chuyên gia diễn họa 3D.
NHIỆM VỤ: Tạo ra một bản render ảnh thực (photorealistic) của công trình được hiển thị trong các hình ảnh tham chiếu.
GIAO THỨC ĐA GÓC NHÌN: 
- Hình ảnh 1 là ĐIỂM NEO CHÍNH (PRIMARY ANCHOR) cho góc độ và khối tích mong muốn.
- TÁI TẠO các khu vực bị che khuất bằng dữ liệu từ các hình ảnh bổ sung.
- BẮT BUỘC: Duy trì tính nhất quán về cấu trúc (số tầng, đường mái, kiểu cửa sổ) trên tất cả các góc nhìn.

PHẦN 0: [KHÓA HÌNH KHỐI & CẤU TRÚC]
[Mô tả chi tiết hình khối, cấu trúc của ảnh gốc bằng tiếng Việt/Anh xen kẽ chuyên ngành]

PHẦN 1: [GHI ĐÈ PHONG CÁCH NGƯỜI DÙNG]
YÊU CẦU RIÊNG: "${selectedAngle === 'p3' ? 'Follow original perspective' : currentAngle?.text}"
VẬT LIỆU: [Liệt kê 5 vật liệu đặc sắc nhất từ ảnh hiện trạng và phong cách ${style.name}]
VIEWPORT: ${currentAngle?.detail || 'Based on primary anchor'}
BỐI CẢNH MÔI TRƯỜNG: [Mô tả bối cảnh phù hợp với phong cách ${style.name}, ánh sáng, thời tiết dựa trên ${analysisMode}]

PHẦN 2: [CHẤT LƯỢNG KỸ THUẬT]
Shot on Fujifilm GFX 100S, RAW photo, 8K resolution, f/11 aperture, ultra-sharp foliage and materials.

### A. POSITIVE PROMPTS (THE "REALITY" ENGINE)
1. CAMERA & OPTICS: Shot on Fujifilm GFX 100S, 35mm Prime Lens, Deep Depth of Field, f/11 Aperture.
2. MATERIALS: High-quality matte white paint, fine-grain stucco, realistic asphalt, high transparency glass.
3. CONTEXT: Hard tropical sunlight, crisp shadows, clear blue sky, high-fidelity tropical foliage.

### B. NEGATIVE CONSTRAINTS (STRICT BAN LIST)
1. BANNED STYLES: 3D Render, CGI, Unreal Engine, Octane, Cartoon, Painting.
2. BANNED VISUALS: Smooth surfaces, glowing walls, plastic skin, oversaturated.
3. DIRTY/BLURRY: Dirty walls, grunge, stains, blurry foreground, bokeh, motion blur.
]

Context information:
Mode: ${analysisMode}
Preset: ${currentPreset?.text || 'None'}
Angle: ${currentAngle?.text || 'Follow Original'}
Notes: ${extraDesc}
Style: ${style.name} (${style.description})

Lưu ý: Viết prompt bằng tiếng Anh chuyên ngành kiến trúc, nhưng các tiêu đề phần (PHẦN 0, PHẦN 1, PHẦN 2) giữ nguyên tiếng Việt.
`;

    try {
      const parts: any[] = [{ text: systemPrompt }];

      // Add Primary Anchor
      const base64Data = image.split(',')[1];
      const mimeType = file.type;
      parts.push({
        inlineData: {
          data: base64Data,
          mimeType: mimeType
        }
      });

      // Add Gallery Images
      gallery.forEach(item => {
        parts.push({
          inlineData: {
            data: item.url.split(',')[1],
            mimeType: item.file.type
          }
        });
      });

      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: [{ parts }]
      });

      if (response.text) {
        setPrompt(response.text);
        addToHistory(`Design (${style.name})`, response.text, 'A', { 
          styleId: style.id, 
          preset: selectedPreset, 
          angle: selectedAngle, 
          extra: extraDesc 
        });
      } else {
        throw new Error("No response from AI");
      }
    } catch (err: any) {
      console.error(err);
      setError(err.message || "Failed to generate prompt. Please try again.");
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <>
      <div className="h-screen bg-dark-bg text-zinc-100 font-sans selection:bg-brand-gold/30 flex overflow-hidden">
      {/* Background decoration */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-brand-gold/5 rounded-full blur-[120px]" />
      </div>

      {/* Sidebar Control Panel */}
      <div className="w-[400px] flex flex-col border-r border-border-subtle bg-dark-bg relative z-20 shadow-2xl">
        <div className="sidebar-header">
          <div className="logo-text">
            <span>Architectural Studio</span>
          </div>
          <div className="header-actions">
            <button 
              className="icon-btn" 
              onClick={() => setIsSidebarCollapsed(!isSidebarCollapsed)}
              title={isSidebarCollapsed ? "Mở rộng" : "Thu gọn"}
            >
              <Maximize2 className={`w-3.5 h-3.5 transition-transform duration-300 ${isSidebarCollapsed ? 'rotate-180 text-brand-gold' : ''}`} />
            </button>
            <button 
              className="icon-btn" 
              onClick={resetApp}
              title="Làm mới công cụ"
            >
              <RefreshCcw className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        <div className={`flex flex-col flex-1 overflow-hidden transition-all duration-300 ${isSidebarCollapsed ? 'max-h-0 opacity-0' : 'max-h-[2000px] opacity-100'}`}>
          <div className="main-tabs">
            <button 
              className={`main-tab-btn ${activeMainTab === 'A' ? 'active' : ''}`}
              onClick={() => setActiveMainTab('A')}
            >
              A. THIẾT KẾ
            </button>
            <button 
              className={`main-tab-btn ${activeMainTab === 'B' ? 'active' : ''}`}
              onClick={() => setActiveMainTab('B')}
            >
              B. CHỈNH SỬA
            </button>
            <button 
              className={`main-tab-btn ${activeMainTab === 'C' ? 'active' : ''}`}
              onClick={() => setActiveMainTab('C')}
            >
              C. TREND
            </button>
            <button 
              className={`main-tab-btn ${activeMainTab === 'D' ? 'active' : ''}`}
              onClick={() => setActiveMainTab('D')}
            >
              D. MỞ RỘNG
            </button>
          </div>

          <div className="flex-1 overflow-y-auto custom-scrollbar p-6 space-y-6">
            {activeMainTab === 'A' && (
              <div className="space-y-6">
                {/* Step 1: Upload */}
                <div className="step-container">
                  <button 
                    onClick={() => toggleAccordion(1)}
                    className={`accordion-btn group ${activeAccordion === 1 ? 'active' : ''}`}
                  >
                    <div className="flex items-center gap-3">
                      <span className="step-num text-serif italic">01</span>
                      <span className="text-[10px] font-bold uppercase tracking-widest group-hover:text-brand-gold transition-colors">Tải lên ảnh hiện trạng</span>
                    </div>
                    <Check className={`w-3 h-3 transition-all duration-300 ${activeAccordion === 1 ? 'opacity-100 translate-y-0 text-brand-gold' : 'opacity-0 translate-y-2'}`} />
                  </button>
                  
                  <AnimatePresence>
                    {activeAccordion === 1 && (
                      <motion.div 
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: 'auto', opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        className="overflow-hidden"
                      >
                        <div className="panel space-y-6">
                          <div className="space-y-3">
                            <div className="flex items-center justify-between">
                              <label className="text-[10px] font-bold uppercase tracking-widest text-text-muted">Primary Anchor Image</label>
                              {image && (
                                <button 
                                  onClick={() => { setImage(null); setFile(null); setPrompt(null); }}
                                  className="text-zinc-500 hover:text-brand-gold p-1 transition-colors"
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                </button>
                              )}
                            </div>
                            <div 
                              onClick={() => !image && fileInputRef.current?.click()}
                              className={`relative aspect-video border transition-all duration-300 group cursor-pointer overflow-hidden ${
                                image ? 'border-border-subtle' : 'border-dashed border-border-subtle hover:border-brand-gold hover:bg-brand-gold/5'
                              }`}
                            >
                              {image ? (
                                <img src={image} alt="Source" className="w-full h-full object-cover" />
                              ) : (
                                <div className="absolute inset-0 flex flex-col items-center justify-center gap-2 p-6 text-center">
                                  <Upload className="w-5 h-5 text-zinc-600 group-hover:text-brand-gold transition-transform group-hover:scale-110" />
                                  <p className="text-[10px] font-bold uppercase tracking-widest text-zinc-500">Tải lên hoặc kéo thả ảnh</p>
                                </div>
                              )}
                              <input type="file" ref={fileInputRef} onChange={handleImageUpload} className="hidden" accept="image/*" />
                            </div>
                          </div>

                          <div className="space-y-3">
                            <label className="text-[10px] font-bold uppercase tracking-widest text-zinc-500 flex flex-col gap-1">
                              Thông tin mở rộng (Gallery)
                              <span className="text-[9px] text-zinc-600 font-normal normal-case italic">* Tải tối đa 5 ảnh mặt đứng phụ, flycam, mái</span>
                            </label>
                            <div 
                              onClick={() => gallery.length < 5 && galleryInputRef.current?.click()}
                              className="upload-gallery-box group py-6"
                            >
                              <Plus className="w-4 h-4 mx-auto mb-1 text-zinc-600 group-hover:text-brand-gold" />
                              <span className="text-[10px] font-bold uppercase">+ Tải thêm ảnh</span>
                              <input type="file" ref={galleryInputRef} onChange={handleGalleryUpload} className="hidden" accept="image/*" multiple />
                            </div>
                            {gallery.length > 0 && (
                              <div className="gallery-preview gap-2">
                                {gallery.map((item, idx) => (
                                  <div key={idx} className="gallery-item group w-12 h-12 rounded-lg border-zinc-800">
                                    <img src={item.url} alt={`Gallery ${idx}`} />
                                    <button onClick={() => removeGalleryImage(idx)} className="remove-btn">
                                      <Trash2 className="w-2.5 h-2.5" />
                                    </button>
                                  </div>
                                ))}
                              </div>
                            )}
                          </div>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>

                {/* Step 2: Mô tả & Style */}
                <div className="step-container">
                  <button 
                    onClick={() => toggleAccordion(2)}
                    className={`accordion-btn group ${activeAccordion === 2 ? 'active' : ''}`}
                  >
                    <div className="flex items-center gap-3">
                      <span className="step-num text-serif italic">02</span>
                      <span className="text-[10px] font-bold uppercase tracking-widest group-hover:text-brand-gold transition-colors">Thiết lập Style & Narrative</span>
                    </div>
                    <Check className={`w-3 h-3 transition-all duration-300 ${activeAccordion === 2 ? 'opacity-100 translate-y-0 text-brand-gold' : 'opacity-0 translate-y-2'}`} />
                  </button>

                  <AnimatePresence>
                    {activeAccordion === 2 && (
                      <motion.div 
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: 'auto', opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        className="overflow-hidden"
                      >
                        <div className="panel space-y-6">
                          <div className="tab-group">
                            <button 
                              className={`tab-btn ${activeTab === 'preset' ? 'active shadow-lg' : ''}`}
                              onClick={() => setActiveTab('preset')}
                            >
                              <Zap className="w-3 h-3" />
                              MẪU CÓ SẴN
                            </button>
                            <button 
                              className={`tab-btn ${activeTab === 'custom' ? 'active shadow-lg' : ''}`}
                              onClick={() => setActiveTab('custom')}
                            >
                              <Settings2 className="w-3 h-3" />
                              TÙY CHỈNH
                            </button>
                          </div>

                          {activeTab === 'preset' ? (
                            <div className="space-y-6 animate-in fade-in slide-in-from-bottom-2 duration-300">
                              <div className="space-y-3">
                                <label className="text-[10px] font-bold uppercase tracking-widest text-zinc-500">CHỌN NHÓM MẪU (CATEGORY)</label>
                                <div className="grid grid-cols-2 gap-2">
                                  {CATEGORIES.map((cat) => (
                                    <button
                                      key={cat.id}
                                      onClick={() => {
                                        setActiveCategory(cat.id);
                                        setSelectedPreset("");
                                      }}
                                      className={`category-btn px-2 py-3 ${activeCategory === cat.id ? 'active' : ''}`}
                                    >
                                      <span className="text-[9px] font-bold uppercase tracking-tighter leading-tight pointer-events-none">{cat.label}</span>
                                    </button>
                                  ))}
                                </div>
                              </div>

                              <div className="space-y-2">
                                <label className="text-[10px] font-bold uppercase tracking-widest text-zinc-500">MẪU PROMPT (PRESET)</label>
                                <select 
                                  className="preset-select text-xs"
                                  value={selectedPreset}
                                  onChange={(e) => setSelectedPreset(e.target.value)}
                                >
                                  {PRESET_DATA[activeCategory]?.map((item, idx) => (
                                    <option key={idx} value={item.value}>
                                      {item.text}
                                    </option>
                                  ))}
                                </select>
                              </div>
                            </div>
                          ) : (
                            <div className="space-y-6 animate-in fade-in slide-in-from-bottom-2 duration-300">
                              <div className="space-y-3">
                                <label className="text-[10px] font-bold uppercase tracking-widest text-zinc-500">Bối cảnh mở rộng (Prompt tự do)</label>
                                <textarea 
                                  className="w-full bg-[#0f0f0f] border border-border-subtle rounded-xl p-4 text-xs text-white placeholder:text-zinc-700 focus:border-brand-gold/50 outline-none transition-colors min-h-[120px] leading-relaxed shadow-inner"
                                  placeholder="Mô tả bối cảnh, thời gian, thời tiết hoặc các yêu cầu đặc biệt khác..."
                                  value={extraDesc}
                                  onChange={(e) => setExtraDesc(e.target.value)}
                                />
                              </div>
                            </div>
                          )}
                          
                          <div className="space-y-4 pt-4 border-t border-zinc-900">
                            <label className="text-[10px] font-bold uppercase tracking-widest text-zinc-500">PHONG CÁCH THIẾT KẾ (DESIGN STYLE)</label>
                            <div className="style-grid">
                              {ARCHITECTURAL_STYLES.map((s) => (
                                <div
                                  key={s.id}
                                  onClick={() => {
                                    setStyle(s);
                                    console.log("Phong cách chọn:", s.name);
                                    console.log("Prompt gửi AI:", s.description);
                                  }}
                                  className={`style-card ${style.id === s.id ? 'active' : ''}`}
                                >
                                  <img src={s.image} alt={s.name} />
                                  <div className="style-name">{s.name}</div>
                                </div>
                              ))}
                            </div>
                          </div>

                          <div className="space-y-3 pt-6 border-t border-zinc-900">
                            <div className="flex items-center justify-between">
                              <label className="text-[10px] font-bold uppercase tracking-widest text-zinc-500">CHẾ ĐỘ XỬ LÝ</label>
                            </div>
                            <div className="mode-grid">
                              <button 
                                className={`mode-btn text-[9px] ${analysisMode === 'PHÂN TÍCH VẬT LIỆU' ? 'active' : ''}`}
                                onClick={() => setAnalysisMode('PHÂN TÍCH VẬT LIỆU')}
                              >
                                PHÂN TÍCH VẬT LIỆU
                              </button>
                              <button 
                                className={`mode-btn text-[9px] ${analysisMode === 'AI TỰ ĐỀ XUẤT' ? 'active' : ''}`}
                                onClick={() => setAnalysisMode('AI TỰ ĐỀ XUẤT')}
                              >
                                AI TỰ ĐỀ XUẤT
                              </button>
                            </div>
                          </div>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>

                {/* Step 3: Đổi góc chụp */}
                <div className="step-container">
                  <button 
                    onClick={() => toggleAccordion(3)}
                    className={`accordion-btn group ${activeAccordion === 3 ? 'active' : ''}`}
                  >
                    <div className="flex items-center gap-3">
                      <span className="step-num text-serif italic">03</span>
                      <span className="text-[10px] font-bold uppercase tracking-widest group-hover:text-brand-gold transition-colors">Đổi góc chụp</span>
                    </div>
                    <Check className={`w-3 h-3 transition-all duration-300 ${activeAccordion === 3 ? 'opacity-100 translate-y-0 text-brand-gold' : 'opacity-0 translate-y-2'}`} />
                  </button>

                  <AnimatePresence>
                    {activeAccordion === 3 && (
                      <motion.div 
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: 'auto', opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        className="overflow-hidden"
                      >
                        <div className="panel space-y-4">
                          <div className="tab-group">
                            <button className="tab-btn active text-[10px]">CƠ BẢN (V1)</button>
                            <button className="tab-btn text-[10px] opacity-40 cursor-not-allowed">NÂNG CAO (V2)</button>
                          </div>

                          <div className="space-y-3">
                            <textarea 
                              className="angle-preview w-full min-h-[80px] bg-[#0f0f0f] border border-[#333] rounded-lg p-3 text-xs text-zinc-400 font-medium leading-relaxed"
                              readOnly
                              value={CAMERA_ANGLES.find(a => a.value === selectedAngle)?.detail || "Nội dung góc chụp sẽ hiển thị ở đây..."}
                            />
                          </div>

                          <div className="space-y-2">
                            <label className="text-[10px] font-bold uppercase tracking-widest text-zinc-500">CHỌN MỘG GÓC CHỤP CÓ SẴN</label>
                            <select 
                              className="preset-select text-xs"
                              value={selectedAngle}
                              onChange={(e) => setSelectedAngle(e.target.value)}
                            >
                              {CAMERA_ANGLES.map((angle) => (
                                <option key={angle.value} value={angle.value}>
                                  {angle.text}
                                </option>
                              ))}
                            </select>
                          </div>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>

                <div className="pt-4">
                  <button 
                    onClick={handleGenerate}
                    disabled={!image || isGenerating}
                    className="generate-btn group shadow-[0_10px_30px_rgba(197,160,89,0.1)]"
                  >
                    {isGenerating ? (
                      <>
                        <Loader2 className="w-4 h-4 animate-spin" />
                        <span>PROCESSING...</span>
                      </>
                    ) : (
                      <>
                        <span>XUẤT PROMPT CHI TIẾT</span>
                        <Sparkles className="w-3.5 h-3.5 group-hover:scale-110 transition-transform" />
                      </>
                    )}
                  </button>
                </div>
              </div>
            )}

            {activeMainTab === 'B' && (
              <div className="animate-in fade-in slide-in-from-bottom-2 duration-300 space-y-2">
                <div className="grid grid-cols-2 gap-2">
                  <div className="space-y-1">
                    <span className="section-label">1. ẢNH HIỆN TRẠNG (GỐC)</span>
                    <div 
                      className="upload-area h-32" 
                      onClick={() => !editImage && editFileInputRef.current?.click()}
                    >
                      {!editImage ? (
                        <div className="flex flex-col items-center">
                          <div className="text-xl text-zinc-600 mb-1">📁</div>
                          <div className="upload-text text-[8px]">Tải ảnh gốc</div>
                        </div>
                      ) : (
                        <>
                          <img src={editImage} alt="Edit Source" className="w-full h-full object-cover rounded-lg" />
                          <button 
                            className="btn-trash"
                            onClick={(e) => {
                              e.stopPropagation();
                              setEditImage(null);
                              setEditFile(null);
                            }}
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </>
                      )}
                      <input 
                        type="file" 
                        ref={editFileInputRef} 
                        onChange={handleEditImageUpload} 
                        className="hidden" 
                        accept="image/*" 
                      />
                    </div>
                  </div>

                  <div className="space-y-1">
                    <span className="section-label">2. ẢNH THAM CHIẾU (TEXTURE)</span>
                    <div 
                      className="upload-area h-32" 
                      onClick={() => !editRefImage && editRefFileInputRef.current?.click()}
                    >
                      {!editRefImage ? (
                        <div className="flex flex-col items-center">
                          <div className="text-xl text-zinc-600 mb-1">🎨</div>
                          <div className="upload-text text-[8px]">Tải texture</div>
                        </div>
                      ) : (
                        <>
                          <img src={editRefImage} alt="Ref Texture" className="w-full h-full object-cover rounded-lg" />
                          <button 
                            className="btn-trash"
                            onClick={(e) => {
                              e.stopPropagation();
                              setEditRefImage(null);
                              setEditRefFile(null);
                            }}
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </>
                      )}
                      <input 
                        type="file" 
                        ref={editRefFileInputRef} 
                        onChange={handleEditRefImageUpload} 
                        className="hidden" 
                        accept="image/*" 
                      />
                    </div>
                  </div>
                </div>

                <button 
                  className="btn-sketch"
                  onClick={() => editImage ? alert("Đã áp dụng bộ lọc Edge Detection (Chuyển sang Sketch).") : alert("Vui lòng tải ảnh lên trước!")}
                >
                  Chuyển sang Sketch
                </button>

                <span className="section-label">3. CHẾ ĐỘ TẠO VÙNG (DRAW MASK)</span>
                <div className="tool-grid">
                  <button 
                    className={`tool-btn ${editTool === 'brush' ? 'active' : ''}`}
                    onClick={() => setEditTool('brush')}
                  >
                    🖌️ Cọ vẽ
                  </button>
                  <button 
                    className={`tool-btn ${editTool === 'lasso' ? 'active' : ''}`}
                    onClick={() => setEditTool('lasso')}
                  >
                    ➿ Lasso
                  </button>
                </div>
                
                <div className="slider-wrapper">
                  <div className="slider-header">
                    <span>Kích thước cọ:</span>
                    <span className="text-brand-gold font-bold">{brushSize}px</span>
                  </div>
                  <input 
                    type="range" 
                    className="brush-slider"
                    min="1" 
                    max="100" 
                    value={brushSize}
                    onChange={(e) => setBrushSize(parseInt(e.target.value))}
                  />
                </div>

                <span className="section-label">4. XÓA MASK</span>
                <button 
                  className="btn-outline"
                  onClick={clearMask}
                >
                  XÓA VÙNG CHỌN (CLEAR)
                </button>

                <span className="section-label">5. YÊU CẦU EDIT</span>
                <textarea 
                  className="prompt-textarea"
                  placeholder="Nhập nội dung muốn chỉnh sửa (VD: Xóa mảng tường cũ, thêm cây xanh nhiệt đới, thay đổi vật liệu thành gỗ óc chó...)"
                  value={editInstruction}
                  onChange={(e) => setEditInstruction(e.target.value)}
                />

                <div className="pt-4">
                  <button 
                    className="generate-btn group"
                    onClick={handleGenerateEdit}
                    disabled={!editImage || isEditGenerating}
                  >
                    {isEditGenerating ? (
                      <>
                        <Loader2 className="w-4 h-4 animate-spin" />
                        <span>PROCESSING...</span>
                      </>
                    ) : (
                      <>
                        <span>TẠO PROMPT EDIT</span>
                        <Sparkles className="w-3.5 h-3.5 group-hover:scale-110 transition-transform" />
                      </>
                    )}
                  </button>
                </div>
              </div>
            )}
            {activeMainTab === 'C' && (
              <div className="animate-in fade-in slide-in-from-bottom-2 duration-300 space-y-6">
                <div className={`trend-banner -mx-6 mb-6 transition-colors duration-500 ${trendMode === 'interior' ? 'bg-[#900000]' : 'bg-brand-gold'}`}>
                  {trendMode === 'interior' ? 'NỘI THẤT - PROMPT GHÉP' : 'NGOẠI THẤT - PROMPT GHÉP'}
                </div>

                <div className="space-y-4">
                  <div className="trend-section px-0 border-none pt-0">
                    <label>XÁC ĐỊNH MỤC TIÊU</label>
                    <div className="trend-grid-2col mb-4">
                      <button 
                        className={`trend-btn ${trendMode === 'exterior' ? 'active' : ''}`}
                        onClick={() => setTrendMode('exterior')}
                      >
                        NGOẠI THẤT
                      </button>
                      <button 
                        className={`trend-btn ${trendMode === 'interior' ? 'active' : ''}`}
                        onClick={() => setTrendMode('interior')}
                      >
                        NỘI THẤT
                      </button>
                    </div>
                  </div>

                  <div className="trend-section px-0 border-none pt-0">
                    <label>1. ẢNH THAM CHIẾU</label>
                    <div 
                      onClick={() => trendFileInputRef.current?.click()}
                      className="relative aspect-video border border-dashed border-border-subtle hover:border-brand-gold hover:bg-brand-gold/5 transition-all duration-300 group cursor-pointer overflow-hidden flex flex-col items-center justify-center p-4 text-center bg-zinc-900/20 rounded-xl"
                    >
                      {trendImage ? (
                        <img src={trendImage} alt="Trend Reference" className="absolute inset-0 w-full h-full object-cover" />
                      ) : (
                        <>
                          <div className="text-2xl mb-2 opacity-50 group-hover:scale-110 transition-transform group-hover:opacity-100">🖼️</div>
                          <p className="text-[11px] font-bold uppercase tracking-widest text-zinc-500 group-hover:text-zinc-300">Nhấn hoặc Kéo Thả ảnh</p>
                        </>
                      )}
                      <input type="file" ref={trendFileInputRef} onChange={handleTrendImageUpload} className="hidden" accept="image/*" />
                    </div>
                  </div>

                  <div className="trend-section px-0 border-none">
                    <label>2. BỐ CỤC (LAYOUT)</label>
                    <div className="trend-grid-2col">
                      {[
                        { id: '1', label: '1 Ảnh' },
                        { id: '2', label: '2 Ảnh' },
                        { id: '4', label: '4 Ảnh' },
                        { id: '6', label: '6 Ảnh' }
                      ].map(layout => (
                        <button 
                          key={layout.id}
                          className={`trend-btn ${trendLayout === layout.id ? 'active' : ''}`}
                          onClick={() => setTrendLayout(layout.id)}
                        >
                          {layout.label}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="trend-section px-0 border-none">
                    <label>3. GÓC NHÌN (VIEW)</label>
                    <div className="trend-grid-2col">
                      {[
                        { id: 'toancanh', label: 'Toàn cảnh' },
                        { id: 'trungcanh', label: 'Trung cảnh' },
                        { id: 'cancanh', label: 'Cận cảnh' },
                        { id: 'sieucan', label: 'Siêu cận' }
                      ].map(view => (
                        <button 
                          key={view.id}
                          className={`trend-btn ${trendView === view.id ? 'active' : ''}`}
                          onClick={() => setTrendView(view.id)}
                        >
                          {view.label}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="pt-4">
                    <button 
                      onClick={handleGenerateTrend}
                      disabled={!trendImage || isGenerating}
                      className="generate-btn group shadow-[0_10px_30px_rgba(197,160,89,0.1)]"
                    >
                      {isGenerating ? (
                        <>
                          <Loader2 className="w-4 h-4 animate-spin" />
                          <span>PROCESSING...</span>
                        </>
                      ) : (
                        <>
                          <span>XUẤT PROMPT GHÉP ẢNH</span>
                          <Sparkles className="w-3.5 h-3.5 group-hover:scale-110 transition-transform" />
                        </>
                      )}
                    </button>
                  </div>
                </div>
              </div>
            )}
            {activeMainTab === 'D' && (
              <div className="animate-in fade-in slide-in-from-bottom-2 duration-300 space-y-4">
                {/* Accordion 1: CHUYỂN ĐỔI ẢNH */}
                <div className="step-container">
                  <button 
                    onClick={() => setExpAccordion(prev => prev === 1 ? 0 : 1)}
                    className={`accordion-btn group ${expAccordion === 1 ? 'active' : ''}`}
                  >
                    <div className="flex items-center gap-3">
                      <Layers className="w-4 h-4" />
                      <span className="text-[10px] font-bold uppercase tracking-widest group-hover:text-brand-gold transition-colors">CHUYỂN ĐỔI ẢNH</span>
                    </div>
                    <Plus className={`w-3 h-3 transition-transform duration-300 ${expAccordion === 1 ? 'rotate-45 text-brand-gold' : ''}`} />
                  </button>
                  <AnimatePresence>
                    {expAccordion === 1 && (
                      <motion.div 
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: 'auto', opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        className="overflow-hidden"
                      >
                        <div className="flex flex-col p-2 gap-1 border-b border-zinc-900 bg-zinc-900/10">
                          <button 
                            onClick={() => setActiveExpTab('ngoaitat')}
                            className={`flex items-center gap-3 p-3 rounded text-[10px] font-bold tracking-widest uppercase transition-all ${activeExpTab === 'ngoaitat' ? 'bg-[#b71c1c] text-white' : 'text-zinc-500 hover:bg-zinc-800'}`}
                          >
                            <span className="w-1.5 h-1.5 rounded-full bg-current" />
                            NGOẠI THẤT
                          </button>
                          <button 
                            onClick={() => setActiveExpTab('noithat')}
                            className={`flex items-center gap-3 p-3 rounded text-[10px] font-bold tracking-widest uppercase transition-all ${activeExpTab === 'noithat' ? 'bg-[#b71c1c] text-white' : 'text-zinc-500 hover:bg-zinc-800'}`}
                          >
                            <span className="w-1.5 h-1.5 rounded-full bg-current" />
                            NỘI THẤT
                          </button>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>

                <div className="space-y-1">
                  <span className="section-label text-zinc-500 text-[9px] font-bold uppercase tracking-widest pl-1">1. ẢNH HIỆN TRẠNG (GỐC)</span>
                  <div 
                    className="upload-area h-32" 
                    onClick={() => !expImage && expFileInputRef.current?.click()}
                  >
                    {!expImage ? (
                      <div className="flex flex-col items-center">
                        <Upload className="w-6 h-6 text-zinc-600 mb-2" />
                        <div className="upload-text text-[10px]">Nhấn hoặc Kéo Thả ảnh</div>
                      </div>
                    ) : (
                      <>
                        <img src={expImage} alt="Extension Source" className="w-full h-full object-cover rounded-lg" />
                        <button 
                          className="btn-trash"
                          onClick={(e) => {
                            e.stopPropagation();
                            setExpImage(null);
                            setExpFile(null);
                            if (expFileInputRef.current) expFileInputRef.current.value = "";
                            setHistory([]);
                            setPrompt(null);
                            setTrendResults([]);
                            setSelectedHistoryId(null);
                          }}
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </>
                    )}
                    <input 
                      type="file" 
                      ref={expFileInputRef} 
                      onChange={handleExpImageUpload} 
                      className="hidden" 
                      accept="image/*" 
                    />
                  </div>
                </div>

                {/* Accordion 2: KỊCH BẢN VIDEO */}
                <div className="step-container">
                  <button 
                    onClick={() => {
                        setExpAccordion(prev => prev === 2 ? 0 : 2);
                        setActiveExpTab('videoscript');
                    }}
                    className={`accordion-btn group ${expAccordion === 2 ? 'active' : ''}`}
                  >
                    <div className="flex items-center gap-3">
                      <Camera className="w-4 h-4" />
                      <span className="text-[10px] font-bold uppercase tracking-widest group-hover:text-brand-gold transition-colors">KỊCH BẢN VIDEO</span>
                    </div>
                    <Plus className={`w-3 h-3 transition-transform duration-300 ${expAccordion === 2 ? 'rotate-45 text-brand-gold' : ''}`} />
                  </button>
                  <AnimatePresence>
                    {expAccordion === 2 && (
                      <motion.div 
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: 'auto', opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        className="overflow-hidden"
                      >
                        <div className="p-4 space-y-6 bg-zinc-900/10">
                          <div className="space-y-3">
                            <label className="text-[9px] font-bold uppercase tracking-widest text-zinc-500">CHẾ ĐỘ TẠO PROMPT</label>
                            <div className="grid grid-cols-2 gap-2">
                              <button 
                                onClick={() => setVideoMode('tong')}
                                className={`p-2 text-[9px] font-bold border rounded transition-all ${videoMode === 'tong' ? 'border-brand-gold bg-brand-gold/10 text-brand-gold' : 'border-zinc-800 text-zinc-600'}`}
                              >
                                TỔNG NHANH
                              </button>
                              <button 
                                onClick={() => setVideoMode('chitiet')}
                                className={`p-2 text-[9px] font-bold border rounded transition-all ${videoMode === 'chitiet' ? 'border-brand-gold bg-brand-gold/10 text-brand-gold' : 'border-zinc-800 text-zinc-600'}`}
                              >
                                CHI TIẾT TỪNG ẢNH
                              </button>
                            </div>
                          </div>

                          <div className="space-y-3">
                            <label className="text-[9px] font-bold uppercase tracking-widest text-zinc-500">ẢNH (TỐI ĐA 10)</label>
                            <div className="flex gap-2 overflow-x-auto pb-2 custom-scrollbar">
                              {videoFrames.map((frame, idx) => (
                                <div key={idx} className="relative w-12 h-12 rounded border border-zinc-800 shrink-0">
                                  <img src={frame} alt={`Frame ${idx}`} className="w-full h-full object-cover rounded" />
                                  <button 
                                    onClick={() => setVideoFrames(prev => prev.filter((_, i) => i !== idx))}
                                    className="absolute -top-1 -right-1 bg-red-600 text-white rounded-full p-0.5"
                                  >
                                    <Trash2 className="w-2 h-2" />
                                  </button>
                                </div>
                              ))}
                              {videoFrames.length < 10 && (
                                <button 
                                  onClick={() => {
                                      const input = document.createElement('input');
                                      input.type = 'file';
                                      input.accept = 'image/*';
                                      input.onchange = (e: any) => {
                                          const file = e.target.files[0];
                                          if (file) {
                                              const reader = new FileReader();
                                              reader.onload = (re: any) => setVideoFrames(prev => [...prev, re.target.result]);
                                              reader.readAsDataURL(file);
                                          }
                                      };
                                      input.click();
                                  }}
                                  className="w-12 h-12 border border-dashed border-zinc-800 rounded flex items-center justify-center text-zinc-600 hover:border-brand-gold hover:text-brand-gold shrink-0 transition-colors"
                                >
                                  <Plus className="w-4 h-4" />
                                </button>
                              )}
                            </div>
                          </div>

                          <div className="grid grid-cols-2 gap-4">
                            <div className="space-y-2">
                                <label className="text-[9px] font-bold uppercase tracking-widest text-zinc-500">THỜI GIAN (GIÂY)</label>
                                <input 
                                    type="number"
                                    className="w-full bg-zinc-900 border border-zinc-800 rounded p-2 text-xs text-zinc-400 outline-none focus:border-brand-gold"
                                    value={videoDuration}
                                    onChange={(e) => setVideoDuration(e.target.value)}
                                    min={1}
                                    step={1}
                                />
                            </div>
                            <div className="space-y-2">
                                <label className="text-[9px] font-bold uppercase tracking-widest text-zinc-500">PHÂN CẢNH (SHOT)</label>
                                <input 
                                    type="number"
                                    className="w-full bg-zinc-900 border border-zinc-800 rounded p-2 text-xs text-zinc-400 outline-none focus:border-brand-gold"
                                    value={videoShots}
                                    onChange={(e) => setVideoShots(parseInt(e.target.value))}
                                    min={1}
                                    max={20}
                                />
                            </div>
                          </div>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>

                <div className="pt-6 sticky bottom-0 bg-dark-bg/80 backdrop-blur-md pb-2 mt-auto">
                    <button 
                      onClick={handleGenerateVideoScript}
                      className="w-full py-4 bg-[#b71c1c] text-white text-[11px] font-bold uppercase tracking-[0.2em] rounded-lg hover:bg-[#d32f2f] transition-all shadow-[0_10px_25px_rgba(183,28,28,0.2)] active:scale-[0.98] flex items-center justify-center gap-3 group"
                    >
                      <Sparkles className="w-4 h-4 text-white/50 group-hover:text-white transition-colors" />
                      XUẤT KỊCH BẢN VIDEO
                    </button>
                </div>
              </div>
            )}
        </div>
      </div>
    </div>

      <div className="flex-1 overflow-hidden relative flex flex-col bg-[#050505]">
        <main className="flex-1 overflow-y-auto p-12 custom-scrollbar">
          <div className="max-w-5xl mx-auto space-y-12">
            <div className="flex flex-col gap-6">
              <div className="bg-zinc-900/10 border border-zinc-800 rounded-2xl p-4 flex items-center justify-between">
                <div className="flex gap-4">
                  {(activeMainTab === 'A' || activeMainTab === 'B') ? (
                    <>
                      <button 
                        onClick={() => {
                          if (isEditing) {
                            setPrompt(tempPrompt);
                            setIsEditing(false);
                          } else {
                            setTempPrompt(prompt || "");
                            setIsEditing(true);
                          }
                        }}
                        disabled={!prompt}
                        className={`px-3 py-1.5 rounded-lg text-[10px] font-bold tracking-wider uppercase transition-all flex items-center gap-2 ${
                          !prompt 
                            ? 'opacity-0 pointer-events-none' 
                            : isEditing
                              ? 'bg-[#1976d2] text-white border border-[#1976d2] shadow-[0_0_12px_rgba(25,118,210,0.4)]' 
                              : 'bg-zinc-800 hover:bg-zinc-700 text-zinc-300 border border-zinc-700 active:scale-[0.98]'
                        }`}
                      >
                        {isEditing ? <div className="text-[10px] mr-1">💾</div> : <div className="text-[10px] mr-1">✏️</div>}
                        {isEditing ? 'Lưu thay đổi' : 'Chỉnh sửa'}
                      </button>
                      <button 
                        onClick={copyViToClipboard}
                        disabled={!prompt || isEditing}
                        className={`px-3 py-1.5 rounded-lg text-[10px] font-bold tracking-wider uppercase transition-all flex items-center gap-2 ${
                          !prompt || isEditing
                            ? 'opacity-0 pointer-events-none' 
                            : viCopied 
                              ? 'bg-[#2e7d32] text-white border border-[#2e7d32] shadow-[0_0_10px_rgba(46,125,50,0.3)]' 
                              : 'bg-zinc-800 hover:bg-zinc-700 text-zinc-300 border border-zinc-700 active:scale-[0.98]'
                        }`}
                      >
                        {viCopied ? <Check className="w-3 h-3" /> : <div className="text-[10px] mr-1">📋</div>}
                        {viCopied ? 'Đã sao chép!' : 'Sao chép Tiếng Việt'}
                      </button>
                    </>
                  ) : (
                    <div className="flex items-center gap-2">
                       <div className="w-2 h-2 rounded-full bg-brand-gold animate-pulse" />
                       <span className="text-[10px] font-bold uppercase tracking-widest text-[#900000]">Trend Analysis Active</span>
                    </div>
                  )}
                  <div className="flex gap-2">
                    <span className="px-2 py-0.5 bg-zinc-800 rounded text-[10px] font-mono text-zinc-400">MJ_v6.0</span>
                    <span className="px-2 py-0.5 bg-zinc-800 rounded text-[10px] font-mono text-zinc-400">RAW_MODE</span>
                  </div>
                </div>
              </div>

              <div className={`flex-1 min-h-[500px] bg-black border rounded-2xl relative flex flex-col overflow-hidden transition-all duration-300 ${isEditing ? 'border-[#1976d2] shadow-[0_0_15px_rgba(25,118,210,0.2)]' : 'border-zinc-800'}`}>
                <div className="prompt-container h-full">
                  <div className="prompt-header">
                    <div className="prompt-title">
                      <div className="flex items-center gap-3">
                        <span className="text-brand-gold text-xl font-serif">A/S</span>
                        <div>
                          <h3 className="text-xs font-bold uppercase tracking-widest text-zinc-100">
                            {activeMainTab === 'C' ? "Engine Output / Midjourney v6 (Trend Mode)" : "Engine Output / Midjourney v6"}
                          </h3>
                          <p className="text-[9px] text-text-muted uppercase tracking-tighter">
                            {activeMainTab === 'C' ? "Tạo 2 prompt cùng lúc cho bố cục ghép ảnh" : "Optimized for architectural high-fidelity renders"}
                          </p>
                        </div>
                      </div>
                    </div>
                    {((activeMainTab === 'C' ? trendResults.length > 0 : prompt)) && (
                      <button 
                        onClick={() => {
                          const text = activeMainTab === 'C' ? trendResults.map(r => `${r.title}\n${r.content}`).join('\n\n') : prompt;
                          if (text) {
                            navigator.clipboard.writeText(text);
                            setCopied(true);
                            setTimeout(() => setCopied(false), 2000);
                          }
                        }}
                        className="btn-copy"
                      >
                        {copied ? (
                          <>
                            <Check className="w-3 h-3" />
                            ĐÃ CHÉP
                          </>
                        ) : (
                          <>
                            <Copy className="w-3 h-3" />
                            SAO CHÉP
                          </>
                        )}
                      </button>
                    )}
                  </div>

                  <div className="flex-1 overflow-hidden relative">
                    <AnimatePresence mode="wait">
                      {(isGenerating || isEditGenerating) ? (
                        <motion.div 
                          key="generating"
                          initial={{ opacity: 0 }}
                          animate={{ opacity: 1 }}
                          exit={{ opacity: 0 }}
                          className="absolute inset-0 flex flex-col items-center justify-center gap-4 text-zinc-500 bg-black/50 backdrop-blur-sm z-20"
                        >
                          <div className="relative w-16 h-16">
                            <motion.div 
                              className="absolute inset-0 border-2 border-brand-gold/20 rounded-full"
                              animate={{ scale: [1, 1.2, 1], opacity: [0.3, 0.6, 0.3] }}
                              transition={{ repeat: Infinity, duration: 2 }}
                            />
                            <Loader2 className="w-full h-full text-brand-gold animate-spin" />
                          </div>
                          <p className="text-[10px] uppercase tracking-widest font-mono text-white animate-pulse">
                            {isEditGenerating ? "PROMPT EDIT ĐANG ĐƯỢC TẠO..." : "Deconstructing geometric nodes..."}
                          </p>
                        </motion.div>
                      ) : error ? (
                        <motion.div 
                          key="error"
                          initial={{ opacity: 0 }}
                          animate={{ opacity: 1 }}
                          className="h-full flex items-center justify-center text-brand-gold text-center px-4"
                        >
                          <p>{error}</p>
                        </motion.div>
                      ) : activeMainTab === 'C' && trendResults.length > 0 ? (
                        <div className="flex-1 flex flex-col min-h-0 bg-transparent overflow-hidden">
                          <div className="flex-1 overflow-y-auto custom-scrollbar p-6">
                            <div className="prompt-grid">
                              {trendResults.map((res, idx) => (
                                <motion.div 
                                  key={idx} 
                                  initial={{ opacity: 0, y: 10 }}
                                  animate={{ opacity: 1, y: 0 }}
                                  transition={{ delay: idx * 0.1 }}
                                  className="prompt-card border border-border-subtle p-4 rounded-lg bg-zinc-900/40 hover:bg-zinc-900/60 transition-colors"
                                >
                                  <div className="flex justify-between items-start mb-3">
                                    <h4 className="card-title">{res.title}</h4>
                                    <button 
                                      onClick={() => copyCardToClipboard(res.content, idx)}
                                      className={`btn-copy transition-all group ${copiedId === idx ? 'border-green-500/50 text-green-500 bg-green-500/5' : ''}`}
                                    >
                                      {copiedId === idx ? (
                                        <>
                                          <Check className="w-3.5 h-3.5" />
                                          <span>ĐÃ CHÉP</span>
                                        </>
                                      ) : (
                                        <>
                                          <Copy className="w-3.5 h-3.5 transition-transform group-hover:scale-110" />
                                          <span>SAO CHÉP</span>
                                        </>
                                      )}
                                    </button>
                                  </div>
                                  <p className="card-body">{res.content}</p>
                                </motion.div>
                              ))}
                            </div>
                          </div>
                        </div>
                      ) : prompt ? (
                        <textarea
                          key="prompt-result"
                          value={isEditing ? tempPrompt : prompt || ""}
                          onChange={(e) => {
                            if (isEditing) {
                              setTempPrompt(e.target.value);
                            }
                          }}
                          readOnly={!isEditing}
                          className="prompt-editor"
                          spellCheck={false}
                        />
                      ) : activeMainTab === 'B' && editImage ? (
                        <div className="h-full flex items-center justify-center bg-black/40 p-4 relative overflow-hidden">
                          <div className="relative inline-block max-h-full">
                            <img 
                              ref={imageRef}
                              src={editImage} 
                              alt="Inpainting Source" 
                              className="max-h-[70vh] object-contain block"
                              onLoad={handleImageLoad}
                              style={{ userSelect: 'none', pointerEvents: 'none' }}
                            />
                            <canvas
                              ref={canvasRef}
                              onMouseDown={startDrawing}
                              onMouseMove={draw}
                              onMouseUp={stopDrawing}
                              onMouseLeave={stopDrawing}
                              className="absolute top-0 left-0 cursor-crosshair"
                              style={{ width: '100%', height: '100%' }}
                            />
                          </div>
                        </div>
                      ) : activeMainTab === 'D' ? (
                        <div className="flex-1 flex flex-col min-h-0 bg-transparent overflow-hidden">
                          <div className="flex-1 overflow-y-auto custom-scrollbar p-6">
                            {activeExpTab === 'ngoaitat' && (
                              <div className="animate-in fade-in slide-in-from-bottom-4 duration-500 space-y-12">
                                <h2 className="text-sm font-bold uppercase tracking-[0.2em] text-white flex items-center gap-3">
                                  <span className="w-8 h-[1px] bg-brand-red" />
                                  NGOẠI THẤT
                                </h2>
                                
                                {EXTERIOR_PROMPT_GROUPS.map((group, gIdx) => (
                                  <div key={gIdx} className="space-y-6">
                                    <h3 className="group-title text-[11px] font-bold uppercase tracking-[0.2em] text-[#b71c1c] border-b border-zinc-900 pb-2 mb-4">
                                      {group.name}
                                    </h3>
                                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                                      {group.cards.map((card, cIdx) => {
                                        const cardId = `style-card-ext-${gIdx}-${cIdx}`;
                                        return (
                                          <div key={cardId} id={cardId} className={`bg-[#111] border border-zinc-900 p-5 rounded-xl hover:border-brand-red/30 transition-all group flex flex-col justify-between h-[220px] ${highlightedCardId === cardId ? 'focus-glow' : ''}`}>
                                            <div>
                                              <h4 className="text-[11px] font-black tracking-tighter text-[#b71c1c] mb-3">{card.title}</h4>
                                              <p className="text-[10px] text-zinc-500 italic line-clamp-5 leading-relaxed">{card.content}</p>
                                            </div>
                                            <button 
                                              onClick={() => {
                                                  if (card.content) {
                                                      const constraint = " CRITICAL REQUIREMENT: Strictly preserve the exact architectural massing, geometric structure, scale, proportions, and perspective of the provided reference image. Do not alter the fundamental building form or add non-existent structural elements.";
                                                      const finalPrompt = `${card.content.trim()} ${constraint} ${expAspectRatio}`;
                                                      navigator.clipboard.writeText(finalPrompt);
                                                      setCopied(true);
                                                      addToHistory(card.title, finalPrompt, 'D', null, cardId);
                                                      setTimeout(() => setCopied(false), 2000);
                                                  }
                                              }}
                                              className="mt-4 w-full py-2 bg-zinc-900 border border-zinc-800 rounded text-[9px] font-bold text-zinc-400 hover:bg-zinc-800 hover:text-white transition-all uppercase tracking-widest"
                                            >
                                              SAO CHÉP NGAY
                                            </button>
                                          </div>
                                        );
                                      })}
                                    </div>
                                  </div>
                                ))}
                              </div>
                            )}

                            {activeExpTab === 'noithat' && (
                              <div className="animate-in fade-in slide-in-from-bottom-4 duration-500 space-y-12">
                                <h2 className="text-sm font-bold uppercase tracking-[0.2em] text-white flex items-center gap-3">
                                  <span className="w-8 h-[1px] bg-brand-red" />
                                  NỘI THẤT
                                </h2>
                                
                                {INTERIOR_PROMPT_GROUPS.map((group, gIdx) => (
                                  <div key={gIdx} className="space-y-6">
                                    <h3 className="group-title text-[11px] font-bold uppercase tracking-[0.2em] text-[#b71c1c] border-b border-zinc-900 pb-2 mb-4">
                                      {group.name}
                                    </h3>
                                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                                      {group.cards.map((card, cIdx) => {
                                        const cardId = `style-card-int-${gIdx}-${cIdx}`;
                                        return (
                                          <div key={cardId} id={cardId} className={`bg-[#111] border border-zinc-900 p-5 rounded-xl hover:border-brand-red/30 transition-all group flex flex-col justify-between h-[220px] ${highlightedCardId === cardId ? 'focus-glow' : ''}`}>
                                            <div>
                                              <h4 className="text-[11px] font-black tracking-tighter text-[#b71c1c] mb-3">{card.title}</h4>
                                              <p className="text-[10px] text-zinc-500 italic line-clamp-5 leading-relaxed">{card.content}</p>
                                            </div>
                                            <button 
                                              onClick={() => {
                                                  if (card.content) {
                                                      const spatialConstraint = " CRITICAL REQUIREMENT: Strictly preserve the exact interior spatial layout, room dimensions, structural boundaries, perspective, and fundamental furniture placement of the provided reference image. Do not alter the core interior volume or add non-existent walls/openings. --v 6.0";
                                                      const finalPrompt = `${card.content.trim()} ${spatialConstraint} ${expAspectRatio}`;
                                                      navigator.clipboard.writeText(finalPrompt);
                                                      setCopied(true);
                                                      addToHistory(card.title, finalPrompt, 'D', null, cardId);
                                                      setTimeout(() => setCopied(false), 2000);
                                                  }
                                              }}
                                              className="mt-4 w-full py-2 bg-zinc-900 border border-zinc-800 rounded text-[9px] font-bold text-zinc-400 hover:bg-zinc-800 hover:text-white transition-all uppercase tracking-widest"
                                            >
                                              SAO CHÉP NGAY
                                            </button>
                                          </div>
                                        );
                                      })}
                                    </div>
                                  </div>
                                ))}
                              </div>
                            )}

                            {activeExpTab === 'videoscript' && (
                              <div className="animate-in fade-in slide-in-from-bottom-4 duration-500 space-y-6 h-full flex flex-col">
                                <div className="flex items-center justify-between">
                                  <h2 className="text-sm font-bold uppercase tracking-[0.2em] text-white flex items-center gap-3">
                                    <span className="w-8 h-[1px] bg-brand-red" />
                                    KỊCH BẢN VIDEO
                                  </h2>
                                </div>
                                
                                <div className="flex-1 bg-[#0a0a0a] border border-zinc-900 rounded-2xl relative overflow-hidden flex flex-col group/container">
                                  <div className="absolute top-0 left-0 p-4 z-20">
                                     <span className="text-[9px] font-bold uppercase tracking-[0.2em] text-zinc-600 bg-zinc-950 px-3 py-1 rounded-full border border-zinc-900">KỊCH BẢN VIDEO CHI TIẾT</span>
                                  </div>
                                  
                                  <div className="flex-1 flex flex-col relative">
                                    {isVideoScriptLoading ? (
                                      <div className="absolute inset-0 flex flex-col items-center justify-center p-12 space-y-6 animate-in fade-in duration-500">
                                         <div className="relative">
                                             <div className="w-16 h-16 border-2 border-brand-red/20 border-t-brand-red rounded-full animate-spin" />
                                             <div className="absolute inset-0 bg-brand-red/10 blur-[30px] rounded-full scale-150 animate-pulse" />
                                         </div>
                                         <div className="space-y-2 text-center max-w-sm">
                                             <p className="text-xs font-bold uppercase tracking-widest text-zinc-300">Đang phân tích cấu trúc không gian và tổng hợp kịch bản...</p>
                                             <p className="text-[9px] text-zinc-600 uppercase tracking-tighter">(Analyzing spatial structure and synthesizing script)</p>
                                         </div>
                                      </div>
                                    ) : videoScriptResult ? (
                                      <div className="flex-1 overflow-y-auto p-12 pt-16 custom-scrollbar animate-in scale-in-95 fade-in duration-500">
                                         <div className="script-result-content markdown-body text-zinc-300 text-xs leading-relaxed max-w-3xl mx-auto">
                                           <ReactMarkdown>{videoScriptResult}</ReactMarkdown>
                                         </div>
                                         <div className="flex justify-center mt-12 pb-6">
                                           <button 
                                             onClick={() => {
                                               navigator.clipboard.writeText(videoScriptResult);
                                               setCopied(true);
                                               setTimeout(() => setCopied(false), 2000);
                                             }}
                                             className="px-8 py-3 bg-zinc-900 border border-zinc-800 rounded-full text-[10px] font-bold text-zinc-400 hover:bg-zinc-800 hover:text-white transition-all uppercase tracking-widest flex items-center gap-3 active:scale-95"
                                           >
                                             <div className="text-xs">📋</div>
                                             SAO CHÉP TOÀN BỘ KỊCH BẢN
                                           </button>
                                         </div>
                                      </div>
                                    ) : (
                                      <div className="absolute inset-0 flex flex-col items-center justify-center text-center p-12 space-y-4">
                                         <div className="relative">
                                             <div className="absolute inset-0 bg-brand-red/10 blur-[40px] rounded-full scale-150 animate-pulse" />
                                             <Camera className="w-12 h-12 text-zinc-800 relative z-10" />
                                         </div>
                                         <div className="space-y-1 relative z-10">
                                             <p className="text-xs font-bold uppercase tracking-widest text-zinc-400">CHƯA CÓ KỊCH BẢN ĐƯỢC TẠO</p>
                                             <p className="text-[10px] text-zinc-600 uppercase tracking-tighter">Vui lòng cấu hình sidebar và nhấn 'Tạo Kịch Bản' để bắt đầu</p>
                                         </div>
                                         <button 
                                           className="relative z-10 px-6 py-2 bg-brand-red/10 border border-brand-red/20 text-brand-red text-[10px] font-bold uppercase tracking-widest rounded hover:bg-brand-red hover:text-white transition-all mt-6 shadow-[0_0_20px_rgba(183,28,28,0.1)] active:scale-95"
                                           onClick={handleGenerateVideoScript}
                                         >
                                           TẠO KỊCH BẢN NGAY
                                         </button>
                                      </div>
                                    )}
                                  </div>

                                  {/* Decor corners */}
                                  <div className="absolute top-0 right-0 w-2 h-2 border-t border-r border-[#333]" />
                                  <div className="absolute bottom-0 left-0 w-2 h-2 border-b border-l border-[#333]" />
                                  <div className="absolute bottom-0 right-0 w-2 h-2 border-b border-r border-[#333]" />
                                </div>
                              </div>
                            )}

                            {!activeExpTab && (
                              <div className="h-full flex flex-col items-center justify-center text-center space-y-4 opacity-30">
                                <Plus className="w-10 h-10 text-zinc-700" />
                                <p className="text-xs font-bold uppercase tracking-widest text-zinc-600">CHỌN TÍNH NĂNG MỞ RỘNG TỪ SIDEBAR</p>
                              </div>
                            )}
                          </div>
                        </div>
                      ) : (
                        <motion.div 
                          key="empty"
                          initial={{ opacity: 0 }}
                          animate={{ opacity: 1 }}
                          className="h-full flex flex-col items-center justify-center gap-4 text-zinc-600 text-center p-8"
                        >
                          {activeMainTab === 'C' ? <Layers className="w-8 h-8 opacity-20" /> : <Camera className="w-8 h-8 opacity-20" />}
                          <p className="text-xs font-bold uppercase tracking-widest">
                            {activeMainTab === 'C' ? "Cấu hình bên trái và nhấn 'Xuất Prompt Ghép Ảnh'" : "Tải ảnh lên và nhấn xuất Prompt để bắt đầu"}
                          </p>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                </div>
              </div>

              {/* Tips Area */}
              <div className="bg-zinc-900/30 border border-zinc-800 rounded-xl p-4 flex gap-4 items-start">
                <div className="p-2 bg-zinc-800 rounded-lg shrink-0">
                  <Sparkles className="w-4 h-4 text-brand-gold" />
                </div>
                <div>
                  <h4 className="text-xs font-bold uppercase tracking-widest text-zinc-400 mb-1">Professional Tips</h4>
                  <p className="text-[10px] text-zinc-500 leading-relaxed">
                    Sử dụng <code className="text-brand-gold bg-brand-gold/10 px-1 rounded">--style raw</code> và tỷ lệ khung hình khớp với ảnh gốc (VD: <code className="text-brand-gold bg-brand-gold/10 px-1 rounded">--ar 16:9</code>) để đạt kết quả tốt nhất trên Midjourney v6.
                  </p>
                </div>
              </div>

              {/* History Bar */}
              <div className="history-bar-container mt-12 bg-zinc-900/10 border border-zinc-800 rounded-2xl overflow-hidden flex flex-col h-[180px]">
                <div className="px-4 py-2 border-b border-zinc-800 flex items-center gap-2">
                   <div className="text-brand-gold text-[10px]">⏱</div>
                   <span className="text-[10px] font-bold uppercase tracking-widest text-zinc-400">LỊCH SỬ TẠO PROMPT</span>
                </div>
                <div className="flex-1 flex gap-4 overflow-x-auto custom-scrollbar p-4 items-center">
                  {history.length === 0 ? (
                    <div className="w-full flex flex-col items-center justify-center text-zinc-700 gap-2 opacity-50">
                      <p className="text-[9px] uppercase font-bold tracking-widest italic">Chưa có lịch sử tạo prompt</p>
                    </div>
                  ) : (
                    history.map((item) => (
                      <button 
                        key={item.id}
                        onClick={() => loadFromHistory(item)}
                        title={typeof item.content === 'string' ? item.content : "Click to view results"}
                        data-target-card={item.targetCardId}
                        className={`history-card shrink-0 flex flex-col justify-between transition-all duration-300 bg-zinc-900/40 border border-zinc-800 p-3 min-w-[120px] rounded-lg ${selectedHistoryId === item.id ? 'history-item-active' : ''}`}
                      >
                        <div className="flex justify-between items-start mb-1">
                          <span className="text-[8px] font-bold text-[#cca852] uppercase tracking-widest">{item.type}</span>
                          <span className="text-[8px] text-zinc-600 font-mono">{item.timestamp}</span>
                        </div>
                        <div className="text-[9px] font-bold text-zinc-300 truncate w-full text-left">{item.title}</div>
                        <div className="text-[7px] text-zinc-600 mt-1 uppercase tracking-tighter">Click to locate style</div>
                      </button>
                    ))
                  )}
                </div>
              </div>
            </div>

            <footer className="pt-8 border-t border-zinc-900 flex flex-col md:flex-row items-center justify-between gap-4 text-zinc-600 text-[9px] font-mono tracking-widest uppercase">
              <p>© 2026 ARCHIVAULT AI SYSTEM // ALL RIGHTS RESERVED</p>
              <div className="flex gap-4">
                <span>STATUS: OPERATIONAL</span>
                <span>ENGINE: GEMINI 1.5 FLASH</span>
              </div>
            </footer>
          </div>
        </main>

        <style>{`
          .custom-scrollbar::-webkit-scrollbar {
            width: 4px;
          }
          .custom-scrollbar::-webkit-scrollbar-track {
            background: transparent;
          }
          .custom-scrollbar::-webkit-scrollbar-thumb {
            background: #27272a;
            border-radius: 10px;
          }
          .custom-scrollbar::-webkit-scrollbar-thumb:hover {
            background: #3f3f46;
          }
        `}</style>
      </div>
    </div>
    <AnimatePresence>
      {copied && (
        <motion.div
          initial={{ opacity: 0, y: 50, x: '-50%' }}
          animate={{ opacity: 1, y: 0, x: '-50%' }}
          exit={{ opacity: 0, y: 20, x: '-50%' }}
          className="fixed bottom-8 left-1/2 -translate-x-1/2 z-50 px-6 py-3 bg-[#b71c1c] text-white text-[10px] font-bold uppercase tracking-[0.2em] rounded-full shadow-2xl shadow-red-900/40 flex items-center gap-3 border border-red-500/30"
        >
          <Check className="w-4 h-4" />
          ĐÃ SAO CHÉP PROMPT KÈM RÀNG BUỘC
        </motion.div>
      )}
    </AnimatePresence>
    </>
  );
}
