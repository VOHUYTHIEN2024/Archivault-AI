export const CATEGORIES = [
  { id: 'gocpho', label: 'GÓC PHỐ' },
  { id: 'duongpho', label: 'ĐƯỜNG PHỐ' },
  { id: 'bietthu', label: 'BIỆT THỰ & CỔ ĐIỂN' },
  { id: 'nongthon', label: 'NÔNG THÔN & KHÁC' }
];

export const PRESET_DATA: Record<string, { value: string; text: string; prompt?: string }[]> = {
  gocpho: [
    { value: "", text: "-- Chọn Mẫu GÓC PHỐ --" },
    { value: "gp1", text: "1: Mặt tiền Phố Sinh động, Nhà Phố, Biệt Thự", prompt: "Vibrant street facade with townhouses and villas." },
    { value: "gp2", text: "2: Mặt tiền Phố Sinh động, Nhà Phố, Biệt Thự", prompt: "Dynamic street scene featuring elegant townhouses." },
    { value: "gp3", text: "3: Mặt tiền Đường phố Đô thị, Nhà Phố, Biệt Thự", prompt: "Urban street facade highlighting modern architecture." },
    { value: "gp4", text: "4: Mặt tiền Đường phố Đô thị, Nhà Phố, Biệt Thự", prompt: "Sophisticated city street view with residential buildings." },
    { value: "gp5", text: "5: Ngã Ba Khu Dân Cư, Đời Sống Thường Nhật", prompt: "Residential intersection capturing daily neighborhood life." },
    { value: "gp6", text: "6: Ngã Ba Khu Dân Cư, Đời Sống Thường Nhật", prompt: "Local corner scene with a mix of architectures." },
    { value: "gp7", text: "7: Ngã Tư Phố Thị, Giao Thông Nhộn Nhịp", prompt: "Busy urban intersection with commercial and residential mix." },
    { value: "gp8", text: "8: Góc Phố Biệt Thự Vườn, Yên Tĩnh", prompt: "Quiet corner featuring garden villas and lush greenery." },
    { value: "gp9", text: "9: Góc Phố Hiện Đại, Sau Cơn Mưa", prompt: "Modern corner architecture with reflective wet surfaces after rain." },
    { value: "gp10", text: "10: Ngã Tư Khu Dân Cư, Nắng Gắt", prompt: "Sun-drenched residential intersection with sharp shadows." },
    { value: "gp11", text: "11: Khu Đô Thị Mới, Sau Cơn Mưa", prompt: "New urban area facade with a fresh post-rain atmosphere." },
    { value: "gp12", text: "12: Ngã tư Phố đêm Nhộn nhịp", prompt: "Stunning night scene at a busy city intersection with lights." },
    { value: "gp13", text: "13: KHU ĐÔ THỊ QUY HOẠCH, MÂY", prompt: "Planned urban area under a dramatic cloudy sky." },
    { value: "gp14", text: "14: Góc Phố Sau Mưa", prompt: "Atmospheric corner scene with soft lighting and wet pavement." },
    { value: "gp15", text: "15: Biệt Thự & Xe Trắng", prompt: "Luxury villa facade with a white car parked prominently." }
  ],
  duongpho: [
    { value: "", text: "-- Chọn Mẫu ĐƯỜNG PHỐ --" },
    { value: "dp1", text: "PHỐ 1: Mặt Tiền Nhà Phố Yên Tĩnh", prompt: "Quiet townhouse facade in a serene residential street." },
    { value: "dp2", text: "PHỐ 2: Mặt Tiền Đô Thị Sầm Uất", prompt: "Bustling urban facade with vibrant city life." },
    { value: "dp3", text: "PHỐ 3: Mặt Tiền Đô Thị Hiện Đại & Thanh Bình", prompt: "Modern urban facade in a peaceful district." },
    { value: "dp4", text: "PHỐ 4: Mặt Tiền Phố Tự Nhiên", prompt: "Natural street facade integrated with greenery." },
    { value: "dp5", text: "PHỐ 5: Mặt Tiền Quy Hoạch Mới", prompt: "New urban planning facade with clean architecture." },
    { value: "dp6", text: "PHỐ 6: Mặt Tiền Phố Sau Mưa", prompt: "Street facade after rain with reflective surfaces and soft light." },
    { value: "dp7", text: "PHỐ 7: Lô Đất Trống Râm Mát", prompt: "Shady vacant lot in an urban neighborhood context." },
    { value: "dp8", text: "PHỐ 8: Phố Liền Kề Châu Âu, Nắng Chiều Lấp Lánh", prompt: "European-style row house street under shimmering afternoon sun." },
    { value: "dp9", text: "PHỐ 9: Biệt Thự Nhiệt Đới, Cảnh Quan Sang Trọng", prompt: "Tropical villa with luxurious landscaping." },
    { value: "dp10", text: "PHỐ 10: Nhà Phố Bình Yên, Nét Đời Thường Việt Nam", prompt: "Peaceful townhouse capturing Vietnamese everyday life." },
    { value: "dp11", text: "PHỐ 11: Biệt Thự & Porsche", prompt: "Luxury villa with a high-end sports car parked in front." },
    { value: "dp12", text: "PHỐ 12: Phố Hiện Đại", prompt: "Sleek and modern city street facade." },
    { value: "dp13", text: "PHỐ 13: Đại Lộ Hiện Đại, Bóng Nắng Sắc Nét", prompt: "Modern boulevard with sharp sunlight and dramatic shadows." },
    { value: "dp14", text: "PHỐ 14: Biệt Thự Cao Cấp", prompt: "High-end luxury villa facade." },
    { value: "dp15", text: "PHỐ 15: Mặt Tiền Nhà Phố, Đường Nội Bộ Yên Tĩnh 2", prompt: "Quiet internal residential street townhouse facade version 2." },
    { value: "dp16", text: "PHỐ 16: Biệt Thự & Cảnh Quan Xanh", prompt: "Villa with lush green landscaping." }
  ],
  bietthu: [
    { value: "", text: "-- Mẫu BIỆT THỰ & CỔ ĐIỂN --" },
    { value: "bt_1", text: "1: CỔ ĐIỂN: Sang Trọng & Quyền Quý", prompt: "Luxurious and majestic classical villa architecture with intricate detailing." },
    { value: "bt_2", text: "2: Dinh thự Tân Cổ Điển, Khu Đô thị Cao cấp", prompt: "Neoclassical mansion in a high-end urban district, elegant proportions." },
    { value: "bt_3", text: "3: Biệt Thự Cổ Điển Góc Sân Vườn, Phong Cách Resort", prompt: "Classical villa at a garden corner with a resort-style atmosphere." },
    { value: "bt_4", text: "4: Mặt Tiền Phố Sang Trọng, Quy Hoạch Đồng Bộ", prompt: "Luxury street facade within a uniformly planned high-end area." },
    { value: "bt_11", text: "11: Sân vườn Resort Nhiệt đới, đông dương", prompt: "Tropical resort garden with Indochine architectural influences." },
    { value: "bt_12", text: "12: BIỆT THỰ THƯỢNG LƯU", prompt: "Elite luxury villa with sophisticated architectural elements." },
    { value: "bt_14_1", text: "14: GÓC 2 MẶT TIỀN 1 ĐƯỜNG NHIỀU MÂY", prompt: "Two-frontage corner villa on a cloudy day with dramatic lighting." },
    { value: "bt_14_2", text: "14: NẮNG VÀO CÔNG TRÌNH, BIỆT THỰ SANG", prompt: "Luxury villa bathed in sunlight highlighting its architectural form." }
  ],
  nongthon: [
    { value: "", text: "-- Chọn Mẫu NÔNG THÔN & PROMPT KHÁC --" },
    { value: "nt_1", text: "NÔNG THÔN: Yên Bình & Dân Dã", prompt: "Peaceful and rustic rural landscape with traditional elements." },
    { value: "nt_2", text: "SÂN VƯỜN 01: Cảnh Quan Resort Nhiệt Đới, Sân Đá Tự Nhiên", prompt: "Tropical resort garden landscape with natural stone flooring." },
    { value: "nt_3", text: "SÂN VƯỜN 02: Cảnh Quan Đô Thị Hiện Thực Cao Độ, Cây Xanh Chân Thực Rực Rỡ Dưới Nắng Ấm", prompt: "Hyper-realistic urban landscape with vibrant green trees under warm sunlight." },
    { value: "nt_4", text: "SÂN VƯỜN 03: Sự Giao Thoa Giữa Mộc Mạc và Đời Sống, ngã tư", prompt: "A blend of rustic charm and everyday life at a neighborhood intersection." },
    { value: "nt_5", text: "LÀNG 4: Mặt Tiền Nhà Quê, Yên Bình (chính diện)", prompt: "Serene front view of a traditional countryside house." },
    { value: "nt_6", text: "LÀNG 5: Mặt Tiền Nhà Vườn Sinh Thái, Tre Trúc", prompt: "Eco-friendly garden house facade featuring bamboo and tropical plants." },
    { value: "nt_7", text: "LÀNG 6: Mặt Tiền Đường Quê Yên Tĩnh, Rợp Bóng Cây", prompt: "Quiet countryside road facade shaded by lush overhanging trees." },
    { value: "nt_8", text: "LÀNG 7: Mặt Tiền Nhà Quê Bên Ao, Giờ Vàng", prompt: "Countryside house by a pond captured during the golden hour." },
    { value: "nt_9", text: "Phố Đêm Sinh Động, Ánh Sáng Ấm", prompt: "Vibrant night street scene with warm, inviting lighting." },
    { value: "nt_10", text: "Ngã tư Phố đêm Nhộn nhịp", prompt: "Bustling city intersection at night with dynamic lights." },
    { value: "nt_11", text: "Phố Đêm, Ánh Sáng Ấm Cúng", prompt: "Cozy night street atmosphere with flickering warm lights." },
    { value: "nt_12", text: "Phố thị Việt Nam Ban ngày, Nhà Phố", prompt: "Vietnamese city street during daytime featuring typical townhouses." },
    { value: "nt_13", text: "Lô đất trống Ven đô, Nhà Phố", prompt: "Vacant suburban lot surrounded by modern townhouse developments." },
    { value: "nt_14", text: "Biệt thự Đồi view Biển, Biệt thự", prompt: "Hillside villa with a spectacular panoramic ocean view." },
    { value: "nt_15", text: "Biệt thự Triền đồi, Tựa Sơn Hướng Thủy", prompt: "Villa nestled on a hillside with classic mountain-backing and water-facing orientation." },
    { value: "nt_16", text: "Khu Đô Thị Mới, Sau Cơn Mưa", prompt: "Sleek new urban area reflecting a fresh atmosphere after rainfall." },
    { value: "nt_17", text: "Đường Lên Biệt Thự Đồi, Giờ Xanh (Blue Hour)", prompt: "Road leading to a hillside villa captured during the magical blue hour." },
    { value: "nt_18", text: "Phố Đêm Nhộn Nhịp, Phơi Sáng (Long Exposure)", prompt: "Bustling night street captured with long exposure trail lights." }
  ]
};

export const CAMERA_ANGLES = [
  { value: "", text: "-- Chọn một góc chụp có sẵn --", detail: "" },
  { value: "p1", text: "Góc 1: Mặt đứng chính diện công trình...", detail: "Mặt đứng chính diện công trình, các phương ngang song song tuyệt đối với khung ảnh, không biến dạng phối cảnh, đối xứng và cân bằng." },
  { value: "p2", text: "Góc 2: Góc chụp phối cảnh 3/4 bên trái...", detail: "Góc chụp phối cảnh 3/4 bên trái, thể hiện rõ cả mặt tiền và hông nhà, nhấn mạnh chiều sâu kiến trúc." },
  { value: "p3", text: "Góc 3: Góc chụp phối cảnh 3/4 bên phải...", detail: "Góc chụp phối cảnh 3/4 bên phải, thể hiện rõ cả mặt tiền và hông nhà, nhấn mạnh chiều sâu kiến trúc." },
  { value: "p4", text: "Góc 4: Góc chụp từ trên cao nhìn xuống (drone view)...", detail: "Góc chụp từ trên cao nhìn xuống (drone view), bao quát toàn bộ công trình và khuôn viên cảnh quan xung quanh." },
  { value: "p5", text: "Góc 5: Góc chụp từ dưới đất nhìn lên...", detail: "Góc chụp từ dưới đất nhìn lên, tạo cảm giác công trình cao lớn, uy nghi và bề thế." },
  { value: "p6", text: "Góc 6: Góc chụp cận cảnh chi tiết...", detail: "Góc chụp cận cảnh chi tiết, tập tập trung vào vật liệu mặt tiền and khu vực cửa chính." },
  { value: "p7", text: "Góc 7: Góc chụp nhìn xuyên qua hàng cây...", detail: "Góc chụp nhìn xuyên qua hàng cây hoặc cảnh quan, tạo khung tự nhiên bao bọc lấy công trình." },
  { value: "p8", text: "Góc 8: Góc chụp ban đêm with ánh sáng nhân tạo...", detail: "Góc chụp ban đêm with ánh sáng nhân tạo, nhấn mạnh hệ thống đèn, bầu trời màu xanh, cây xanh in công trình có ánh đèn hắt sáng, đường hơi ướt nhẹ." },
  { value: "p9", text: "Góc 9: Góc chụp toàn cảnh panorama quét ngang...", detail: "Góc chụp toàn cảnh panorama quét ngang, lấy trọn vẹn bối cảnh and môi trường xung quanh công trình." },
  { value: "p10", text: "Góc 10: Góc chụp thẳng đứng từ trên xuống...", detail: "Góc chụp thẳng đứng từ trên xuống, mô phỏng phong cách bản vẽ mặt bằng tổng thể kiến trúc." }
];
